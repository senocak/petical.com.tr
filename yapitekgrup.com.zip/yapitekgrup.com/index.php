﻿<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->
<html  lang="tr">
<!--<![endif]-->
<?php 
session_start(); 
include("config.php"); 

$sayfa="";
$sayfa= isset($_GET['sayfa']) ? $_GET['sayfa'] : "anasayfa";
$url=$sayfa;
 if($url != null){
	$url = rtrim($url, "/");
	$url = explode("/", $url);
}else{
   unset($url); 
}

if($url[0]=="tr") {
	echo '<script type="text/javascript">history.go(-1)</script>';
	$_SESSION['dil']="tr";
}
if($url[0]=="en") {
	echo '<script type="text/javascript">history.go(-1)</script>';
	$_SESSION['dil']="en";
}  
?>
<head>

<!-- Meta -->
<meta charset="utf-8">
<meta name="keywords" content="Yapıtek, proje" />
<meta name="description" content="Yapıtek Proje Grubu">
<meta name="author" content="Promolarge Ad. Agency / Plarges Corp. / Mirina Agency Ltd.">
<title><?php echo $ayarlar->title;?></title>

<!-- Mobile Meta -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Favicons -->
<link rel="shortcut icon" href="<?php echo Site_url;?>/admin/images/favicon.png"> 

<!-- Web Fonts  -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,700,700italic,900italic,900,500italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,700,600italic,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arimo:400,700' rel='stylesheet' type='text/css'>

<!--[if lt IE 9]>
	<script src="js/libs/respond.min.js"></script>
	<![endif]-->

<!-- Bootstrap core CSS -->
<link href="<?php echo Site_url;?>/css/bootstrap.css" rel="stylesheet">

<!-- FontAwesome icons CSS -->
<link href="<?php echo Site_url;?>/admin/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet">

<!-- Theme Styles CSS-->
<link href="<?php echo Site_url;?>/css/styles.css" rel="stylesheet">
<link href="<?php echo Site_url;?>/css/accordion.css" rel="stylesheet">
<link href="<?php echo Site_url;?>/js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="<?php echo Site_url;?>/js/owl-carousel/owl.theme.css" rel="stylesheet">
<link href="<?php echo Site_url;?>/js/rs-plugin/css/settings.css" rel="stylesheet" />
<link href="<?php echo Site_url;?>/js/flexslider/flexslider.css" rel="stylesheet">

	<link rel="Stylesheet" type="text/css" href="<?php echo Site_url;?>/css/jquery_ui.css" /> 
	<link rel="Stylesheet" type="text/css" href="<?php echo Site_url;?>/css/superTabs.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo Site_url;?>/css/isotope.css">

<!--[if lt IE 9]>
	<script src="js/libs/html5.js"></script>
	<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  WebFontConfig = {
    google: { families: [ 'Lobster::latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
      '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })(); </script>
</head>
<body>
<div class="body">  
  <header>
    <div class="container">
      <div class="col-md-12" style="margin-left:-10px;"> 
        <!-- Logo -->
        <div class="col-md-4">
          <h1 class="logo"><a href="<?php echo Site_url;?>/"><img src="<?php echo Site_url;?>/admin/images/<?php echo $ayarlar->logo;?>" alt="Yapıtek"></a></h1>
        </div>
        
        <!-- Navmenu -->
        <div class="col-md-8">
          <div id='topnav'>
            <ul class="top-menu">
              <li class='<?php if($url[0]=="" or $url[0]=="anasayfa") echo " active ";?> has-sub' > <a href='<?php echo Site_url;?>/'><span><?php echo $anasayfa;?></span></a> </li>
              <li class='<?php if($url[0]=="kurumsal") echo " active ";?> has-sub'> <a href='<?php echo Site_url;?>/kurumsal'><span><?php echo $kurumsal;?></span></a>
                <ul>
                <?php 
				$kur_sorgu=mysql_query("select * from kurumsal order by siralama asc");
				 while($kur_yaz=mysql_fetch_object($kur_sorgu)){
					 if($_SESSION['dil']=="tr"){$baslik=$kur_yaz->baslik_tr;}
					 if($_SESSION['dil']=="en"){$baslik=$kur_yaz->baslik_en;}
					 if($kur_yaz->url != "hizmetlerimiz")echo "<li><a href='".Site_url."/kurumsal/$kur_yaz->url'>".$baslik."</a></li>";
				 }
				 
				 echo "<li><a href='".Site_url."/kurumsal/ekibimiz'>".$ekibimiz."</a></li>";
				 ?>  
                </ul>
              </li>
              <li class="<?php if($url[0]=="hizmetlerimiz") echo " active ";?> has-sub"> <a class="nav-sub" href='<?php echo Site_url;?>/hizmetlerimiz'><span><?php echo $hizmetler;?></span></a> </li>
              <li class="<?php if($url[0]=="projeler") echo " active ";?> has-sub"> <a href='<?php echo Site_url;?>/projeler'><span><?php echo $projeler;?></span></a> </li>
              <li class="<?php if($url[0]=="iletisim") echo " active ";?> has-sub"> <a href='<?php echo Site_url;?>/iletisim'><span><?php echo $iletişim;?></span></a> </li>
			<?php if($_SESSION['dil']=="tr"){?><li class='has-sub'> <a href='<?php echo Site_url;?>/en'><span><img src="<?php echo Site_url;?>/admin/images/en_flag.jpg" /></span></a> </li><?php } ?>
			<?php if($_SESSION['dil']=="en"){?><li class='has-sub'> <a href='<?php echo Site_url;?>/tr'><span><img src="<?php echo Site_url;?>/admin/images/tr_flag.jpg"/></span></a> </li><?php } ?>
            </ul>
          </div>
        </div>
        
      </div>
    </div>
  </header>
  <!-- Header --> 
  
  <?php if($url[0]=="" or $url[0]=="anasayfa"){?>
  <!-- Slider -->
  <div class="fullwidthbanner-container" >
    <div class="fullwidthbanner">
      <ul>
        <li data-transition="random" data-slotamount="7" data-masterspeed="1000"> <img src="images/slide/sc1.jpg" alt="slide" data-fullwidthcentering="true">
          <div class="tp-caption large_black sfr" data-x="290" data-y="24" data-speed="1500" data-start="600" data-easing="easeInOutBack"> <img src="images/slide/sck.png" alt="slide" > </div>
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="145" data-speed="600" data-start="800" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;">Mühendislik ve Mimarlığın <br> </h5>
          </div>
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="175" data-speed="600" data-start="1100" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;">buluştuğu nokta...<!--<br><a href="#">devamı</a>--><!--<i class="fa fa-plus"></i>--></h5>
          </div>
          <div class="tp-caption lfb carousel-caption-inner" data-x="30" data-y="230" data-speed="1500" data-start="1700" data-easing="easeInOutBack"> 
            <!--<button type="button" class="button-grey" >devamı..</button>--> 
          </div>
        </li>
        <li data-transition="random" data-slotamount="7" data-masterspeed="1000"> <img src="images/slide/sb1.jpg" alt="slide" data-fullwidthcentering="true">
          <div class="tp-caption large_black sfr" data-x="350" data-y="0" data-speed="1500" data-start="600" data-easing="easeInOutBack"> <img src="images/slide/sbk.png" alt="slide" > </div>
       
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="255" data-speed="900" data-start="1400" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;">Yaratıcı Çözümler, </h5>
          </div>
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="285" data-speed="900" data-start="1800" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;"><!--<i class="fa fa-plus"></i>-->Yaşanacak mekanlar...</h5>
          </div>
          <div class="tp-caption lfb carousel-caption-inner" data-x="30" data-y="340" data-speed="1500" data-start="1700" data-easing="easeInOutBack">
          <!--<button type="button" class="button-grey" >devamı..</button>--> 
          
        </li>
        <li data-transition="random" data-slotamount="7" data-masterspeed="1000"> <img src="images/slide/sa1.jpg" alt="slide" data-fullwidthcentering="true">
          <div class="tp-caption large_black sfr" data-x="290" data-y="24" data-speed="1500" data-start="600" data-easing="easeInOutBack"> <img src="images/slide/sak.png" alt="slide" > </div>
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="198" data-speed="600" data-start="800" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;">Çevreye duyarlı, </h5>
          </div>
          <div class="tp-caption large_black lfl carousel-caption-inner" data-x="30" data-y="228" data-speed="600" data-start="1100" data-easing="easeInOutQuad">
            <h5 style="font-family: 'Lobster', cursive;">İşlevsel projeler... <!--<br><a href="#">devamı</a>--><!--<i class="fa fa-plus"></i>--></h5>
          </div>
          <div class="tp-caption lfb carousel-caption-inner" data-x="30" data-y="210" data-speed="1500" data-start="1700" data-easing="easeInOutBack"> 
            <!--<button type="button" class="button-grey" >devamı..</button>--> 
          </div> 
        </li>
      </ul>
    </div>
  </div>
  <!-- Slider --> 
  
  <!-- Services -->
  <div class="section">
    <div class="container"> 
	<?php 
		$service_sorgu=mysql_query("select * from kurumsal where url != 'hizmetlerimiz' order by siralama asc limit 0,3 ");
		while($service_yaz=mysql_fetch_object($service_sorgu)){ 
				if($_SESSION['dil']=="tr"){
					$baslik=$service_yaz->baslik_tr;
					$icerik=strip_tags($service_yaz->icerik_tr);
				}
				if($_SESSION['dil']=="en"){
					$baslik=$service_yaz->baslik_en;
					$icerik=strip_tags($service_yaz->icerik_en);
				}
				
				if(strlen($icerik)>=111){
					if(preg_match('/(.*?)\s/i',substr($icerik,111),$dizi))$icerik=substr($icerik,0,111+strlen($dizi[0]))."...";  
				}else{
					$icerik.="";
				}
				echo '<a style="color:black;" href="'.Site_url.'/kurumsal/'.$service_yaz->url.'"><div class="col-lg-4 col-md-4">
						<div class="services">
						  <div class="shadow-right"></div>
						  <span class="service-ico1">
						  <div style="color:#fff; margin-left:1px; margin-top:1px;"><img src="images/y.png" /></div>
						  </span>
						  <h3>'.$baslik.'</h3>
						  <p>'.$icerik.'</p>
						</div>
					</div></a>'; 
		}
	?>
    </div>
  </div>
  <!-- Services --> 
  
  <!-- Recent Projects - Carousel -->
  <div class="container home-works">
    <div class="row">
      <div class="col-lg-12">
        <h2 class="section-title"><span><?php echo $son_projeler;?></span></h2>
      </div>
      <div id="owl-example" class="owl-carousel">
		 <?php 
		 $project_sorgu=mysql_query("select * from projeler order by siralama asc");
		 while($project_yaz=mysql_fetch_object($project_sorgu)){ 
			 $resim=mysql_fetch_object(mysql_query("select * from projeler_resim where proje_id='$project_yaz->id'"))->url; 
			 if($resim=="") $resim="bos.jpg"; 
			  echo ' <div class="item works-content">
					  <div class="works-overlay"> <img style="width: 100%; height: 100%;" class="img-responsive" src="'.Site_url.'/admin/images/proje_resimler/'.$resim.'"  alt=""/> <span>
						<div class="zoom">
						  <div class="zoom-info"> <a class="lightbox-popup" href="'.Site_url.'/admin/images/proje_resimler/'.$resim.'">'.$resmi_gor.'</a> <a href="'.Site_url.'/projeler/'.$project_yaz->proje_url.'">'.$proje_detay.'</a> </div>
						</div>
						</span> </div>
					  <h4>'.$project_yaz->proje_adi.'</span></h4>
					</div> ';
		 }
		 ?>
      </div>
    </div>
  </div>
  <!-- Recent Projects - Carousel -->
  
  <div class="section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="col-lg-12 no-padding">
            <h2 class="section-title"><span><?php echo $katalog;?></span></h2>
          </div>
          <div class="col-lg-12 no-padding clearfix media white-panel-katalog" style="text-align: center;"><a href="<?php echo Site_url;?>/yapitekkatalog.pdf"><img style="width: 100%; height: 50%;" src="<?php echo Site_url;?>/admin/images/<?php echo $ayarlar->katalog_resim;?>" /></a></div>
        </div>
        <div class="col-lg-6 about-home">
          <div class="col-lg-12 no-padding">
            <h2 class="section-title"><span><?php echo $kısaca;?></span></h2>
          </div>
          <div class="col-lg-12 no-padding clearfix media "> 
		  <?php 
			$biz_kimiz_yaz=mysql_fetch_object(mysql_query("select * from kurumsal where url='hakkimizda'"));
		  ?>
		  <img class="pull-left" src="<?php echo Site_url."/admin/images/kurumsal_resimler/".$biz_kimiz_yaz->resim;?>" width="50%" alt=""/>
			<?php 
				if($_SESSION['dil']=="tr"){$detay=$biz_kimiz_yaz->icerik_tr; }
				if($_SESSION['dil']=="en"){$detay=$biz_kimiz_yaz->icerik_en; }
				if(strlen($detay)>=800){
					if(preg_match('/(.*?)\s/i',substr($detay,800),$dizi))$detay=substr($detay,0,800+strlen($dizi[0]))."...";  
				}else{
					$detay.="";
				}
			?>
			<p><?php echo $detay;?><a href="<?php echo Site_url;?>/kurumsal"><?php echo $devam;?></a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <?php 
	}elseif($url[0]=="kurumsal" ){
		?> 
<div class="page-head"></div>
<div class="space60"></div>
<!-- Content-wrap -->
<div class="container">
    <div class="row">
	<?php			
				$url_bir="";
				$url_bir=isset($url[1]) ? $url[1] : "hakkimizda";
				if($url_bir != "ekibimiz")				{
				$sorgula=mysql_fetch_object(mysql_query("select * from kurumsal where url='$url_bir'")); 
				if(!$sorgula)$url_bir="hakkimizda";
				
			$sorgula=mysql_fetch_object(mysql_query("select * from kurumsal where url='$url_bir'")); 
			if($sorgula->sol_menu_visible==1){  ?>
        <div class="col-md-4">
           <div class="side-widget">
				<!--<h5><span>Categories</span></h5>-->
				<ul class="category">
				<?php 
				$kur_sorgu=mysql_query("select * from kurumsal order by siralama asc");
				 while($kur_yaz=mysql_fetch_object($kur_sorgu)){
					 if($_SESSION['dil']=="tr"){$baslik=$kur_yaz->baslik_tr;}
					 if($_SESSION['dil']=="en"){$baslik=$kur_yaz->baslik_en;}
					 if($kur_yaz->url != "hizmetlerimiz")echo "<li><a href='".Site_url."/kurumsal/".$kur_yaz->url."'>".$baslik."</a></li>";
				 }
				 
				 echo "<li><a href='".Site_url."/kurumsal/ekibimiz'>".$ekibimiz."</a></li>";
				 ?> 
				</ul>                
                <a href="<?php echo Site_url;?>/yapitekkatalog.pdf"><img style="width: 50%; height: 50%;margin-left: 100px;" src="<?php echo Site_url;?>/admin/images/<?php echo $ayarlar->katalog_resim;?>" class="img-responsive" alt=""/></a>
				<blockquote><?php echo $katalog;?></blockquote>
				<!--<cite>John doe <span>Manager</span></cite>-->
			</div>
        </div>
      <?php 
	}
	
			$kur_yaz=mysql_fetch_object(mysql_query("select * from kurumsal where url='$url_bir'"));
			if($_SESSION['dil']=="tr"){
				$baslik=$kur_yaz->baslik_tr;
				$detay=$kur_yaz->icerik_tr;
			}
			if($_SESSION['dil']=="en"){
				$baslik=$kur_yaz->baslik_en;
				$detay=$kur_yaz->icerik_en;
			}
			}
		
	  ?> 
	  
	  
	  <?php 
	  if($url_bir=="ekibimiz"){
		  include("gridder/ekibimiz.php");
	  }else if($url[0]=="hizmetlerimiz"){
		  include("gridder/hizmetlerimiz.php");
		  
	  }else{
	  
	  
	  ?>
	  
	  
        <div class="col-md-8">
          <?php if($kur_yaz->resim_visible==1){?>  <div class="content-img">
                <img src="<?php echo Site_url;?>/admin/images/kurumsal_resimler/<?php echo $kur_yaz->resim;?>" class="img-responsive" alt=""/>
                <div class="shadow-left-big"></div>
            </div>
            <div class="space50"></div>
		  <?php } ?>
          <h4 class="section-title"><span><?php echo $baslik;?></span></h4>
            <p><?php echo $detay;?> </p> 
			 
			
			
            <div class="textbox">
                <div class="line"></div>
                <div class="space15"></div> 
                <div class="space10"></div>
                <div class="line"></div>
            </div>
        </div>
	  <?php }?>
</div>

	</div>		<?php  
	}elseif($url[0]=="hizmetlerimiz"){
	?> 
		<div class="page-head"></div>
		<div class="space60"></div> 
			<div class="container">
				<div class="row"> 
					<div class="col-md-8"> 
						 <?php include("gridder/hizmetlerimiz.php");?> 
						<div class="textbox">
							<div class="line"></div>
							<div class="space15"></div> 
							<div class="space10"></div>
							<div class="line"></div>
						</div>
					</div> 
				</div> 
			</div> 
	<?php
	}elseif($url[0]=="projeler"){ 
		$projeler_bir="";
		$projeler_bir=isset($url[1]) ? $url[1] : ""; 
		if(!$projeler_bir){
?> 
<div class="page-head"><div class="container"></div></div>
<div class="space80"></div>
<section id="portfolio" class="container no-padding"> 
    <div class="portfolio-inner nport">
        <div id="folio" class="isotope col-md-12 no-padding"> 
		<?php 
		$proje_sorgu=mysql_query("select * from projeler order by siralama");
		while($proje_yaz=mysql_fetch_object($proje_sorgu)){
			$proje_resim=mysql_fetch_object(mysql_query("select * from projeler_resim where proje_id='$proje_yaz->id'"));
			if(!$proje_resim) $resim="bos.jpg";
			else $resim=$proje_resim->url;
			echo '<div class="folio-item col-md-3 no-padding isotope-item web">
					<div class="item works-content">
						<div class="works-overlay">
							<img class="img-responsive" style="width: 230px;height: 165px;" src="'.Site_url.'/admin/images/proje_resimler/'.$resim.'" alt=""/>
							<span>
								<div class="zoom">
									<div class="zoom-info">
										<a class="lightbox-popup" href="'.Site_url.'/admin/images/proje_resimler/'.$resim.'">Resmi Gör</a>
										<a href="'.Site_url.'/projeler/'.$proje_yaz->proje_url.'">Proje Detay</a>
									</div>
								</div>
							</span>
						</div>
						<h4>'.$proje_yaz->proje_adi.'</h4>
					</div>
				</div>';
		}
		?>
        </div><div class="space20"></div>
    </div>
</section> 
	<?php  
		}else{ 
	?>
<div class="page-head"><div class="container"></div></div>
<div class="space60"></div>
<div class="container">
    <div class="row">
        <div class="item works-content">
            <div class="row">
                <div class="col-md-9">
                    <div class="works-overlay">
                        <div id="psingle-slider" class="flexslider">
                            <ul class="slides">
							<?php 
							$proje_cek=mysql_fetch_object(mysql_query("select * from projeler where proje_url='$projeler_bir'"));
							if(!$proje_cek) $proje_cek=mysql_fetch_object(mysql_query("select * from projeler limit 0,1"));
							$resim_sorgu1=mysql_query("select * from projeler_resim where proje_id='$proje_cek->id'");
							while($resim_sorgu2=mysql_fetch_object($resim_sorgu1)){
								echo '<li><img src="'.Site_url.'/admin/images/proje_resimler/'.$resim_sorgu2->url.'" alt=""/></li>';
							}
							?> 
                            </ul>
                            <div class="shadow-left-big"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 project-content"><h4><?php echo $ozellikler;?></h4><p><?php echo $proje_cek->proje_ozellikleri; ?></p></div>
            </div>
        </div>
    </div>
</div>
<!-- Portfolio-single Content -->

<!-- Related Projects -->
<div class="space60"></div>
<div class="container home-works">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="section-title"><span><?php echo $benzer_projeler;?></span></h2>
        </div>
        <div id="recent-projects1" class="owl-carousel">
			 <?php 
			 $benzer_proje_sorgu=mysql_query("select * from projeler");
			 while($benzer_proje_yaz=mysql_fetch_object($benzer_proje_sorgu)){
				 $resim_cek=mysql_fetch_object(mysql_query("select * from projeler_resim where proje_id='$benzer_proje_yaz->id'"));
				 if(!$resim_cek) $resim="bos.jpg";
				 else $resim=$resim_cek->url;
				 echo '<div class="item works-content">
							<div class="works-overlay"><a href="'.Site_url.'/projeler/'.$benzer_proje_yaz->proje_url.'"><img class="img-responsive" src="'.Site_url.'/admin/images/proje_resimler/'.$resim.'" alt=""/></a></div>
							<h4>'.$benzer_proje_yaz->proje_adi.'</h4>
						</div>';
			 }
			 ?>
        </div>
    </div>
</div>
<!-- Related Projects -->
<div class="space80"></div>
			<?php 
		}
	}elseif($url[0]=="iletisim"){
		?>	
<div class="page-head"><div class="container"></div></div>
<div class="space60"></div>
<div class="container">
    <div class="row">
        <div class="col-md-12 map-wrap">
            <div class="content-img">
                <div class="map">
                    <div class="gmap"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3196.6114340044282!2d34.53154966083521!3d36.755896855135546!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15278a5f68955c63%3A0x1903647b305a3196!2sY%C3%BCksek+Harman+Cd.%2C+Yeni%2C+33330+Mezitli%2FMersin%2C+T%C3%BCrkiye!5e0!3m2!1str!2s!4v1451581454095" width="100%" height="437" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                    <div class="shadow4"></div>
                </div>
                <div class="shadow-left-big"></div>
            </div>
        </div>
    </div>
</div>
<div class="space50"></div>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <h4 class="Section-title"><span><?php echo $iletisim1; ?></span></h4>
            <div class="space40"></div>
            <form class="contact-form" method="post">
                <div class="row">
                    <div class="col-md-4"><input type="text" name="ad" class="form-control" placeholder="<?php echo $isim;?>"/></div> 
                    <div class="col-md-4"><input type="email" name="email" class="form-control" placeholder="<?php echo $email;?>"/></div>
                </div>
                <textarea rows="7" name="mesaj" style="width: 495px; height: 154px; resize:vertical ;" class="form-control" placeholder="<?php echo $mesaj;?>"></textarea>
                <div class="space25"></div>
				<input type="submit" value="<?php echo $gonder;?>" name="gonder" class="button-blue btn" /> 
            </form>
        </div>
        <div class="col-md-3">
            <h4 class="Section-title"><span><?php echo $adres;?></span></h4>
            <div class="contact-info">
                <div class="space25"></div>
                <p style="margin-left:20px;"><?php echo $ayarlar->adres; ?></p>
                <div class="space30"></div>
                <p style="margin-left:20px;"><?php echo $tel;?> : <?php echo $ayarlar->telefon; ?></p>
                <p style="margin-left:20px;"><a href="#" style="color: rgb(250, 206, 24);"><?php echo $ayarlar->site_url; ?></a></p>
            </div>
        </div>
    </div>
</div>
<div class="space70"></div> 
	<?php  
	$gonder="";
	$gonder=isset($_POST["gonder"]) ? $_POST["gonder"] : "";
	if($gonder){
		$adsoyad=$_POST["ad"];
		$email=$_POST["email"];
		$mesaj=$_POST["mesaj"];
		$tarih=date("d/m/Y" );
		$query = mysql_query("insert into mesaj (isim,email,mesaj,tarih,okundu) values ('$adsoyad','$email','$mesaj','$tarih','0')");
		if($query) echo "<script>alert('".$mesaj1."');</script>";
		if(!$query) echo "<script>alert('".$mesaj2."');</script>"; 
	}
}
?>
</div>
  <div class="footer-bottom"> <a style="background-color:gray;" class="back-top" href="#"><i class="fa fa-chevron-up"></i></a>
    <div class="container">
      <div class="row-fluid">
        <div class="col-md-6">
        <p><?php echo $sosyal;?></p>
          <p><?php print($ayarlar->footer); ?> / Powered By <a href="https://bilgimedya.com.tr/">BilgiMedya</a></p>
        </div>
        <div class="col-md-6">
          <ul class="top-contact">
            <li><i class="fa fa-phone"></i><?php echo $ayarlar->telefon; ?></li>
            <li><i class="fa fa-envelope"></i><a href="mailto:<?php echo $ayarlar->email; ?>"><?php echo $ayarlar->email; ?></a></li>
          </ul><br>
          <ul class="social-info">
            <li><a href="<?php echo $ayarlar->facebook; ?>"><span><i class="fa fa-facebook"></i></span></a></li>
            <li><a href="<?php echo $ayarlar->twitter; ?>"><span><i class="fa fa-twitter"></i></span></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer - Copyright --> 
<!-- JavaScript --> 
<script src="<?php echo Site_url;?>/js/jquery-1.8.3.min.js"></script> 
<script src="<?php echo Site_url;?>/js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script> 
<script src="<?php echo Site_url;?>/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script> 
<script src="<?php echo Site_url;?>/js/rs-plugin/rs.home.js"></script> 
<script src="<?php echo Site_url;?>/js/superTabs.js"></script> 
<script type="text/javascript" src="http://www.google.com/jsapi"></script> 
<script type="text/javascript">google.load("jqueryui", "1.7.2");</script> 
<script src="<?php echo Site_url;?>/js/bootstrap.js"></script> 
<script src="<?php echo Site_url;?>/js/flexslider/jquery.flexslider.js"></script> 
<script src="<?php echo Site_url;?>/js/owl-carousel/owl.carousel.js"></script> 
<script src="<?php echo Site_url;?>/js/jquery.akordeon.js"></script> 
<script src="<?php echo Site_url;?>/js/jflickrfeed.min.js"></script> 
<script src="<?php echo Site_url;?>/js/tab.js"></script> 
<script src="<?php echo Site_url;?>/js/jquery.isotope.min.js"></script> 
<script src="<?php echo Site_url;?>/js/jquery.mobilemenu.js"></script> 
<script src="<?php echo Site_url;?>/js/magnific-popup/jquery.magnific-popup.js"></script> 
<script src="<?php echo Site_url;?>/js/main.js"></script> 
<script src="<?php echo Site_url;?>/js/jquery-ui.js"></script> 
<script src="<?php echo Site_url;?>/js/jquery.tweet.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="<?php echo Site_url;?>/js/jquery.gmap.js"></script>
<script type="text/javascript" src="<?php echo Site_url;?>/js/contact.js"></script>
</body>
</html>