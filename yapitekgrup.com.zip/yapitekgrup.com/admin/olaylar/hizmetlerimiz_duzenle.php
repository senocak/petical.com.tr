<?php
$gelen= $_GET["id"];
$sorgu_yaz=mysql_fetch_object(mysql_query("select * from hizmetlerimiz where id='$gelen'"));
if(isset($sorgu_yaz->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=hizmetlerimiz";</script>';

?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Hizmetlerimiz</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Hizmetlerimiz</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Ad Soyad</td><td><input required  type="text" name="baslik" value="<?php echo $sorgu_yaz->baslik; ?>" class="form-control"/></td></tr>
							<tr><td>Açıklama</td><td><textarea required  style="resize:vertical;" class="ckeditor" name="aciklama" class="form-control"><?php echo $sorgu_yaz->aciklama; ?></textarea></td></tr>
							<tr><td>Resim Kırpma</td><td> 
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline1" value="1" type="radio">Resim Kırpılsın</label>
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline2" value="0" checked="" type="radio">Resim Kırpılmasın</label>  
							</td></tr>
							 
							<tr><td>Resim Düzenle</td><td><input type="file" onChange="showimagepreview(this);"  id="exampleInputFile1"  class="btn btn-default"  name="resim" id="resim"></td></tr>
							<tr><td></td><td><img src="<?php echo Site_url;?>/admin/images/hizmetlerimiz/<?php echo $sorgu_yaz->resim;?>" width="100px" title="Kayıtlı Resim"> » <img title="Yeni Resim" id="imgview" src="<?php echo Site_url;?>/admin/images/bos.jpg"  width="100px" /> </td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="btn btn-outline btn-primary btn-lg btn-block" class="form-control" value="Gönder"/></td></tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
$id=$gelen;
$aa = mysql_fetch_array(mysql_query("select * from hizmetlerimiz where id='$id'"));
if(isset($_POST["gonder"])){
	$baslik = $_POST['baslik']; 
	$aciklama = $_POST['aciklama']; 
	$kırp = $_POST['kırp'];  
	require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
	$resim = $_FILES['resim']; // Form'dan yüklenen resim.
	$yukle = new upload($resim); //Sınıfımızı Başlatıyoruz.
	$klasor = 'images/hizmetlerimiz'; //Resmin Yükleneceği Klasör 
	$url = url_duzenle(kucuk($baslik));
	if($aa["baslik"]!= $baslik  || $aa["aciklama"]!= $aciklama){
		$baslik_update=mysql_query("UPDATE hizmetlerimiz SET baslik='$baslik',aciklama='$aciklama' where id='$id'");
		if($baslik_update){
			echo '<script>alert("Düzenleme Başarılı");</script>';
			echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
		}else{
			echo mysql_error();
		}
	}
	if ($yukle->uploaded) {
		if($kırp==1){
			$yukle->image_resize          = true;
			$yukle->image_ratio_fill      = true;
			$yukle->image_x               = 700;
			$yukle->image_y               = 520;
		}
		//$yukle->file_new_name_body = $url;
		$yukle->process($klasor);
		if($yukle->processed) {
			unlink("images/hizmetlerimiz/".$aa['resim']);
			$baslik_update2=mysql_query("UPDATE hizmetlerimiz SET resim='".$yukle->file_dst_name."' where id='$id'");
			if($baslik_update2){
				echo '<script>alert("Düzenleme Başarılı");</script>";</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
			}else{
				echo '<script>alert("Düzenleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz_duzenle&id=$gelen';</script>";
				$yukle->clean();
			}
		}else{
			echo '<script>alert("Düzenleme Başarısız");</script>';
			echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz_duzenle&id=$gelen';</script>";
		}
	}
}