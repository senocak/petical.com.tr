<?php 
session_destroy();
echo '<meta http-equiv="refresh" content="0;URL='.Site_url.'admin/login.php">';
echo "<script language='javascript'>location.href='".Site_url."/admin/login.php';</script>";
?>