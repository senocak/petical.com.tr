<script src="js/jquery-1.11.2.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>

<div class="row"><div class="col-lg-12"><h1 class="page-header">Anasayfa</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Kurumsal<div style="float:right;"><a href="<?php echo Site_url;?>/admin/index.php?sayfa=kurumsal_ekle">Yeni Ekle</a></div></div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped">
						<?php
						$limit = 10;
						$sira=1;
						$page = @$_GET["page"];
						if($page>1) $sira+=$limit*$page-$limit;
						if(empty($page) or !is_numeric($page)) { $page = 1; }
							$count			 = mysql_num_rows(mysql_query("SELECT id FROM kurumsal"));
							$toplamsayfa	 = ceil($count / $limit);
							$baslangic		 = ($page-1)*$limit;

						$yazdir_sorgu = mysql_query("SELECT * FROM kurumsal  ORDER BY siralama asc LIMIT $baslangic,$limit") or die(mysql_error());
						if(mysql_num_rows($yazdir_sorgu)=="0"){
							if($toplamsayfa == 0 ){ 
								echo '<br><br><br><br><center><h1>Kayıt Bulunamadı...  <div class="fa fa-warning-sign"></div></h1></center><br><br><br><br>'; 
							}else{
								if($page > $toplamsayfa) echo '<script language="javascript">location.href="index.php?sayfa=kurumsal";</script>';
							}
						}else{
							?>
							<thead><tr><th>#</th><th>Başlık</th><th>Resim</th><th>İçerik</th><th>Düzenle</th></tr></thead>
							<tbody id="sortable">
							<?php
							while ($gelen = mysql_fetch_array($yazdir_sorgu)){
								if($gelen['baslik_tr']!="Hizmetlerimiz" and $gelen['baslik_tr']!="Ekibimiz"){
								$gelen['icerik_tr']=strip_tags($gelen['icerik_tr']);
								if(strlen($gelen['icerik_tr'])>=100){
									if(preg_match('/(.*?)\s/i',substr($gelen['icerik_tr'],100),$dizi))$gelen['icerik_tr']=substr($gelen['icerik_tr'],0,100+strlen($dizi[0]))."...";  
								}else{
									$gelen['icerik_tr'] .="";
								}
									?>
									<tr id="item-<?php echo $gelen['id'];?>">
									<td class="sortable"><?php echo "<b>".$sira."<b>"; $sira++; ?></td>
									<td style="width:20%;"><?php echo $gelen['baslik_tr']; ?></td>
									<td style="width:30%;"><img src="<?php echo Site_url."/admin/images/kurumsal_resimler/".$gelen['resim']; ?>" width="30%"/></td>
									 
									<td style="width:50%;"><?php echo $gelen['icerik_tr'];?></td>
									<td style="width:3%;">
										<a href="<?php echo Site_url;?>/admin/index.php?sayfa=kurumsal_duzenle&id=<?php echo $gelen["id"];?>"><p class="fa fa-edit"></p></a>
										<?php if($gelen['url']=="hakkimizda" or $gelen['url']=="hizmetlerimiz"){}else{?><a href="<?php echo Site_url;?>/admin/index.php?sayfa=kurumsal_sil&id=<?php echo $gelen["id"];?>"><p class="fa fa-remove"></p></a><?php } ?>
									</td>
									</tr>
								<?php }  
							}
						}
						echo '</tbody> </table> <div class="bs-example"><ul class="pagination pagination-lg">';
						 if($count > $limit) :
						  $x = 2;
						  $lastP = ceil($count/$limit);
						  if($page > 1){
						  $onceki = $page-1;
						  echo "<li ><a  href='index.php?sayfa=kurumsal&page=$onceki'><div class='fa fa-chevron-left'></div></a></li> ";
						  }
						   if($page==1) echo "  <li class='active'><a >1</a></li>";
						  else  echo "  <li><a href='index.php?sayfa=kurumsal'>1</a></li>";
						  if($page-$x > 2) {
						   echo "  <li><a>...</a></li> ";
							$i = $page-$x;
						  } else {
							$i = 2;
						  }
						  for($i; $i<=$page+$x; $i++) {
						   if($i==$page) echo "<li  class='active'><a href='index.php?sayfa=kurumsal&page=$i'>$i</a></li>";
						   else echo "<li ><a href='index.php?sayfa=kurumsal&page=$i'>$i</a></li>";
						   if($i==$lastP) break;
						  }
						  if($page+$x < $lastP-1) {
						   echo "  <li><a>...</a> <a  href='index.php?sayfa=kurumsal&page=$lastP'>$lastP</a></li> ";

						  } elseif($page+$x == $lastP-1) {
						  echo "<li ><a  href='index.php?sayfa=kurumsal&page=$lastP'>$lastP</a></li> ";
						  }
						  if($page < $lastP){
						  $sonraki = $page+1;
						  echo "<li ><a href='index.php?sayfa=kurumsal&page=$sonraki'><div class='fa fa-chevron-right'></div></a></li> ";
						   }
						endif;  ?> 
						</ul></div>
				</div>
			</div>
		</div>
	</div>
</div>  


<style type="text/css">
	.sortable { cursor: move; }
</style>
<script type="text/javascript">
$(function() {
	$( "#sortable" ).sortable({
		revert: true,
		handle: ".sortable",
		stop: function (event, ui) {
			var data = $(this).sortable('serialize');

			$.ajax({
				type: "POST",
				dataType: "json",
				data: data,
				url: "sirala.php?p=kurumsalSirala",
				success: function(msg){
					alert( msg.kurumsalSiralaIslemMsj );
				}
			});	                      				
		}
	});
	$( "#sortable" ).disableSelection();	                      		
});	                      	
</script>	


<?php 
if(isset($_GET["izin"])){
	$izin=$_GET["izin"];
	$id=$_GET["id"];
	if($izin==1) $izin1=0;
	if($izin==0) $izin1=1;
	
	$update=mysql_query("update kurumsal set yorum_izin='$izin1' where id='$id'");
	if($update) echo "<script>alert('Değişiklikler Kaydedildi');</script><script>history.go(-1);</script>";
}
?>