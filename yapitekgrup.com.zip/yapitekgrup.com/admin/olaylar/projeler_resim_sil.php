<?php
$id = $_GET['id'];
$projeler_resim = mysql_fetch_object(mysql_query("select * from projeler_resim where id='$id'"));
if(isset($projeler_resim->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=projeler";</script>';;
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Proje Resim Sil</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Proje Resim Sil</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<center>
					<h2>Silmek İstediğinize Emin Misiniz?</h2><br><br>	<form method="post">
					<input class="btn btn-success btn-lg" type="submit" value="Evet" name="sil">
					<input class="btn btn-danger btn-lg" type="submit" value="Hayır" name="silme">   </form>
					</center> 
				</div>
			</div>
		</div>
	</div>
</div>
<?php
if(isset($_POST["sil"])){
	$sil = mysql_fetch_object(mysql_query("select * from projeler_resim where id='$id'"));
	$del  = mysql_query("delete from projeler_resim where id='$id'");
	unlink("images/proje_resimler/$sil->url");
	echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=projeler";</script>';
}
if(isset($_POST["silme"])){
	echo '<script type="text/javascript">history.go(-2)</script>';
}