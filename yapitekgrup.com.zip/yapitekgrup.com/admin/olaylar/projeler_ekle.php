<div class="row"><div class="col-lg-12"><h1 class="page-header">Proje Ekle</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Projeler</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Proje Adı</td><td><input type="text" name="proje_ismi" placeholder="Referans Adı" class="form-control"/></td></tr>
							<tr><td>Resim Özellikleri</td><td><textarea class="ckeditor" name="proje_ozellikleri"></textarea></td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="btn btn-primary"  value="Gönder"/></td></tr>
					</table>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
if(isset($_POST["gonder"])){
$proje_ismi = $_POST['proje_ismi'];
$proje_ozellikleri = $_POST['proje_ozellikleri']; 
$yeni_url = kucuk(url_duzenle($proje_ismi));

if($proje_ismi=="" || $proje_ozellikleri=="")echo '<script>alert("Tüm Alanları Doldurunuz.");</script>";</script>'; 

$update=mysql_query("insert into projeler (proje_adi,proje_url,proje_ozellikleri) values ('$proje_ismi','$yeni_url','$proje_ozellikleri')");
	if($update){
		echo '<script>alert("Düzenleme Başarılı");</script>";</script>';
		echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler';</script>";
	}else{
		echo '<script>alert("Düzenleme Başarısız");</script>';
		echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler';</script>";
		$yukle->clean();
	}
}