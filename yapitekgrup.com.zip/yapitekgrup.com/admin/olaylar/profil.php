<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#username').keyup(function(){
        var username = $(this).val(); // Get username textbox using $(this)
        var Result = $('#result'); // Get ID of the result DIV where we display the results
        if(username.length > 2) { // if greater than 2 (minimum 3)
            Result.html('Yükleniyor...'); // you can use loading animation here
            var dataPass = 'action=availability&username='+username;
            $.ajax({ // Send the username val to available.php
            type : 'POST',
            data : dataPass,
            url  : 'available.php',
            success: function(responseText){ // Get the result
                if(responseText == 0){
                    Result.html('<span class="success">Kullanıcı Adı Alınabilir.</span>');
                }
                else if(responseText > 0){
                    Result.html('<span class="error">Kullanıcı Adı Alınmış.</span>');
                }else{
                    alert('Sorgu Hatası...');
                } 
            }
            });
        }else{ 
			Result.html('<span class="error">En Az 3 Karakter Giriniz.</span>');
        }
        if(username.length == 0) {
            Result.html('');
        }
    });
});
</script>
<style type="text/css">
	.success{color: green;}
	.error{color: red;}
	.content{width:900px;margin:0 auto;} 
</style>



<div class="row"><div class="col-lg-12"><h1 class="page-header">Profil</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Profil</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Kullanıcı Adı </td><td><input type="text" name="kul_adi"  id="username" value="<?php echo $durum; ?>" class="form-control"/><div class="result" id="result"></div></td></tr>
							<tr><td>Kullanıcı Şifresi </td><td><input type="text" name="kul_sifre" placeholder="****" class="form-control"/></td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="form-control" value="Gönder"/></td></tr>
						</table>
					</form>
</div></div></div></div></div>
<?php
if(isset($_POST["gonder"])){
$kul_adi = $_POST['kul_adi'];
$kul_sifre = md5($_POST['kul_sifre']);
	if(($kul_adi != null) and ($kul_sifre!=null)){
		$baslik_update=mysql_query("UPDATE admin SET  kullanici_adi='$kul_adi',sifre='$kul_sifre' where kullanici_adi='$durum'");
		session_destroy();
		echo '<meta http-equiv="refresh" content="0;URL='.Site_url.'admin/login.php">';
		echo "<script language='javascript'>location.href='".Site_url."/admin/login.php';</script>";
	}
}