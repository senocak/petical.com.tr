<?php
$id=$_GET["id"];
$sorgu=mysql_fetch_object(mysql_query("select * from mesaj where id='$id'"));

if(isset($sorgu->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=teklif_mesaj";</script>';;
if($sorgu->okundu==1) $durum=0; else $durum=1;
$update=mysql_query("UPDATE mesaj SET  okundu='$durum' where id='$id'");
//if($update) echo "<script>alert('Güncelleme Başarılı');</script>";
//else echo "<script>alert('Güncelleme Başarısız');</script>";
echo '<script language="javascript">location.href="index.php?sayfa=teklif_mesaj";</script>';