<div class="row"><div class="col-lg-12"><h1 class="page-header">Kurumsal</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Kurumsal</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Başlık-TR</td><td><input required type="text" name="yeni_baslik_tr" placeholder="Yeni Başlık" class="form-control"/></td></tr>
							<tr><td>Başlık-EN</td><td><input required type="text" name="yeni_baslik_en" placeholder="New HeadLine" class="form-control"/></td></tr>
							<tr><td>İçerik-TR</td><td><textarea style="resize: vertical; " class="ckeditor" name="yeni_icerik_tr" class="form-control" placeholder="Yeni İçerik">Yeni İçerik</textarea></td></tr>
							<tr><td>İçerik-EN</td><td><textarea style="resize: vertical; " class="ckeditor" name="yeni_icerik_en" class="form-control" placeholder="Yeni İçerik">Yeni İçerik</textarea></td></tr>
							<tr><td>Resim Kırpma</td><td> 
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline1" value="1" checked="" type="radio">Resim Kırpılsın</label>
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline2" value="0" type="radio">Resim Kırpılmasın</label>  
							</td></tr>
							<tr><td>Resim Düzenle</td><td><input type="file" onChange="showimagepreview(this);" id="exampleInputFile1" class="btn btn-default"  name="resim" id="resim"></td></tr>
							<tr><td></td><td>  <img title="Yeni Resim" id="imgview" src="<?php echo Site_url;?>/admin/images/bos.jpg"  width="100px" /> </td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="btn btn-primary"  value="Gönder"/></td></tr>
					</table>
					</form>
</div></div></div></div></div>
<?php
if(isset($_POST["gonder"])){ 
$yeni_baslik_tr = $_POST['yeni_baslik_tr'];
$yeni_baslik_en = $_POST['yeni_baslik_en'];
$yeni_icerik_tr = $_POST['yeni_icerik_tr'];
$yeni_icerik_en = $_POST['yeni_icerik_en'];
$kırp = $_POST['kırp']; 
require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
$resim = $_FILES['resim']; // Form'dan yüklenen resim.
$yukle = new upload($resim); //Sınıfımızı Başlatıyoruz.
$klasor = 'images/kurumsal_resimler'; //Resmin Yükleneceği Klasör 
$url=kucuk(url_duzenle($yeni_baslik_tr));

if($resim["name"]!=""){
		if ($yukle->uploaded){
		if($kırp==1){
			$yukle->image_resize          = true;
			$yukle->image_ratio_fill      = true;
			$yukle->image_x               = 800;
			$yukle->image_y               = 321;
		}
		$yukle->file_new_name_body = url_duzenle(kucuk($yeni_baslik_tr));
		$yukle->process($klasor);
			if($yukle->processed) {
			$update=mysql_query("insert into kurumsal (baslik_tr,baslik_en,url,resim,icerik_tr,icerik_en) values ('$yeni_baslik_tr','$yeni_baslik_en','$url','$yukle->file_dst_name','$yeni_icerik_tr','$yeni_icerik_en')");
				if($update){
					echo '<script>alert("Düzenleme Başarılı");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=kurumsal';</script>";
				}else{
					echo '<script>alert("Düzenleme Başarısız");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=kurumsal';</script>";
					$yukle->clean();
				}
			}else{
				echo '<script>alert("Düzenleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=kurumsal';</script>";
			}
	}
	}else{
		$update=mysql_query("insert into kurumsal (baslik_tr,baslik_en,url,resim,icerik_tr,icerik_en) values ('$yeni_baslik_tr','$yeni_baslik_en','$url','bos.jpg','$yeni_icerik_tr','$yeni_icerik_en')");
			if($update){
				echo '<script>alert("Düzenleme Başarılı");</script>";</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=kurumsal';</script>";
			}else{
				echo '<script>alert("Düzenleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=kurumsal';</script>";
				$yukle->clean();
			}
	}
}