<div class="row"><div class="col-lg-12"><h1 class="page-header">Kurumsal</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Kurumsal</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Ad Soyad</td><td><input required  type="text" name="ad_soyad" placeholder="Ad Soyad" class="form-control"/></td></tr>
							<tr><td>Ünvan</td><td><input required  type="text" name="unvan" placeholder="Ünvan" class="form-control"/></td></tr>
							<tr><td>Açıklama</td><td><textarea required  style="resize:vertical;" class="ckeditor" name="aciklama" class="form-control"> </textarea></td></tr>
							<tr><td>Resim Kırpma</td><td> 
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline1" value="1" type="radio">Resim Kırpılsın</label>
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline2" value="0" checked="" type="radio">Resim Kırpılmasın</label>  
							</td></tr>
							 
							<tr><td>Resim Ekle</td><td><input type="file" onChange="showimagepreview(this);"  id="exampleInputFile1"  class="btn btn-default"  name="resim" id="resim"></td></tr>
							<tr><td></td><td><img title="Yeni Resim" id="imgview" src="<?php echo Site_url;?>/admin/images/bos.jpg"  width="100px" /> </td></tr>
							<tr><td>CV Düzenle</td><td><input type="file" class="btn btn-default"  name="cv" id="cv"> Lütfen (.doc veya .docx formatında dosya yükleyiniz.)</td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="btn btn-outline btn-primary btn-lg btn-block" class="form-control" value="Gönder"/></td></tr>
						</table>
					</form>
</div></div></div></div></div>
<?php
if(isset($_POST["gonder"])){ 
$ad_soyad = $_POST['ad_soyad'];
$unvan = $_POST['unvan'];
$aciklama = $_POST['aciklama']; 
$kırp = $_POST['kırp'];  
require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
$resim = $_FILES['resim']; // Form'dan yüklenen resim.
$yukle = new upload($resim); //Sınıfımızı Başlatıyoruz.
$klasor = 'images/ekibimiz'; //Resmin Yükleneceği Klasör 
$url=kucuk(url_duzenle($ad_soyad));
$toplam=mysql_num_rows(mysql_query("select * from ekibimiz")); 
if($resim["name"]!=""){
		if ($yukle->uploaded){
		if($kırp==1){
			$yukle->image_resize          = true;
			$yukle->image_ratio_fill      = true;
			$yukle->image_x               = 700;
			$yukle->image_y               = 520;
		}
		$yukle->file_new_name_body = $url;
		$yukle->process($klasor);
			if($yukle->processed) {
			$update=mysql_query("insert into ekibimiz (ad_soyad,unvan,aciklama,siralama,resim) values ('$ad_soyad','$unvan','$aciklama','$toplam','$yukle->file_dst_name')");
				if($update){
					echo '<script>alert("Ekleme Başarılı");</script>';
				//	echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
				}else{
					echo '<script>alert("Ekleme Başarısız");</script>';
				//	echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
					$yukle->clean();
				}
			}else{
				echo '<script>alert("Ekleme Başarısız-'.$yukle->error.'");</script>';
			//	echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
			}
	}
	}else{
		$update=mysql_query("insert into ekibimiz (ad_soyad,unvan,aciklama,siralama) values ('$ad_soyad','$unvan','$aciklama','$toplam')");
			if($update){
				echo '<script>alert("Ekleme Başarılı");</script>";</script>';
			//	echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
			}else{
				echo '<script>alert("Ekleme Başarısız-");</script>';
				//echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
				$yukle->clean();
			}
	} 
	
	$toplam=mysql_num_rows(mysql_query("select * from ekibimiz")); 
	$toplam=$toplam-1;
	$cv = $_FILES['cv']; // Form'dan yüklenen resim.
	$yukle_cv = new upload($cv); //Sınıfımızı Başlatıyoruz.
	$klasor_cv = 'cv'; //Resmin Yükleneceği Klasör  
	if ($yukle_cv->uploaded) {
		//$yukle_cv->allowed = array('application/pdf','application/msword');
		$yukle_cv->file_new_name_body = $url;
		$yukle_cv->process($klasor_cv);
		if($yukle_cv->processed) { 
			$yukle_cv_ekle=mysql_query("update ekibimiz set cv='$yukle_cv->file_dst_name' where siralama='$toplam'"); 
			if($yukle_cv_ekle){
				echo '<script>alert("Ekleme Başarılı.");</script>";</script>';
				//echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
			}else{
				echo '<script>alert("Ekleme Başarısız--'.mysql_error().'");</script>'; 
				$yukle_cv->clean();
			}
		}else{
			echo '<script>alert("Ekleme Başarısız---'.$yukle_cv->error.'");</script>';
				//echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>";
		}
	}
	echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ekibimiz';</script>"; 
}