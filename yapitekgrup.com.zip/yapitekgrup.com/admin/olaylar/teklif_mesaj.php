<div class="row"><div class="col-lg-12"><h1 class="page-header">Anasayfa</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Mesajlar</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped">
<?php
$limit = 10;
$sira=1;
$page = @$_GET["page"];
if(empty($page) or !is_numeric($page)) { $page = 1; }
if($page>1) $sira+=$limit*$page-$limit;
	$count			 = mysql_num_rows(mysql_query("SELECT id FROM mesaj order by id desc"));
	$toplamsayfa	 = ceil($count / $limit);
	$baslangic		 = ($page-1)*$limit;

$yazdir_sorgu = mysql_query("SELECT * FROM mesaj ORDER BY id desc LIMIT $baslangic,$limit") or die(mysql_error());
if(mysql_num_rows($yazdir_sorgu)=="0"){
	if($toplamsayfa == 0 ){ 
		echo '<br><br><br><br><center><h1>Kayıt Bulunamadı...  <div class="fa fa-warning-sign"></div></h1></center><br><br><br><br>'; 
	}else{
		if($page > $toplamsayfa) echo '<script language="javascript">location.href="index.php?sayfa=teklif_mesaj";</script>';
	}
}else{
?>
<thead><tr><th>#</th><th>Ad Soyad</th><th>E-Posta</th><th>Tarih</th><th>Mesaj</th><th>Durum</th><th>İşlemler</th></tr></thead>
<tbody> 
<?php
while ($gelen = mysql_fetch_array($yazdir_sorgu)){
if(strlen($gelen['mesaj'])>=70){ 
if(preg_match('/(.*?)\s/i',substr($gelen['mesaj'],70),$dizi))$gelen['mesaj']=substr($gelen['mesaj'],0,70+strlen($dizi[0]))."...";  
}else{
$gelen['mesaj'] .="";
}
?>
	<tr>
	<td><?php echo "<b>".$sira."<b>"; $sira++; ?></td>
	<td><?php echo $gelen['isim']; ?></td> 
	<td><?php echo $gelen['email']; ?></td>
	<td><?php echo $gelen['tarih']; ?></td>
	<td><?php echo $gelen['mesaj']; ?>...</td>
	<td><?php if($gelen['okundu']==1){
	?><a  href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj_oku&id=<?php echo $gelen['id']; ?>" title="okundu" onclick="return confirm('Okunmadı Olarak İşaretlemek İstediginize Emin Misiniz');"><div class="fa fa-heart"></div></a><?php 
	}else{
	?><a  href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj_oku&id=<?php echo $gelen['id']; ?>" title="okundu" onclick="return confirm('Okundu Olarak İşaretlemek İstediginize Emin Misiniz ?');"><div class="fa fa-heart-o"></div></a><?php 
	}	
	?></td>
	<td><a href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj_icerik&id=<?php echo $gelen["id"];?>"><p class="fa fa-edit"></p></a> <a href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj_sil&id=<?php echo $gelen["id"];?>"><p class="fa fa-remove"></p></a></td>
	</tr>
<?php }  }
echo '</table> <div class="bs-example"><ul class="pagination pagination-lg">';
 if($count > $limit) :
  $x = 2;
  $lastP = ceil($count/$limit);
  if($page > 1){
  $onceki = $page-1;
  echo "<li ><a  href='index.php?sayfa=teklif_mesaj&page=$onceki'><div class='fa fa-chevron-left'></div></a></li> ";
  }
   if($page==1) echo "  <li class='active'><a >1</a></li>";
  else  echo "  <li><a href='index.php?sayfa=teklif_mesaj'>1</a></li>";
  if($page-$x > 2) {
   echo "  <li><a>...</a></li> ";
    $i = $page-$x;
  } else {
    $i = 2;
  }
  for($i; $i<=$page+$x; $i++) {
   if($i==$page) echo "<li  class='active'><a href='index.php?sayfa=teklif_mesaj&page=$i'>$i</a></li>";
   else echo "<li ><a href='index.php?sayfa=teklif_mesaj&page=$i'>$i</a></li>";
   if($i==$lastP) break;
  }
  if($page+$x < $lastP-1) {
   echo "  <li><a>...</a> <a  href='index.php?sayfa=teklif_mesaj&page=$lastP'>$lastP</a></li> ";

  } elseif($page+$x == $lastP-1) {
  echo "<li ><a  href='index.php?sayfa=teklif_mesaj&page=$lastP'>$lastP</a></li> ";
  }
  if($page < $lastP){
  $sonraki = $page+1;
  echo "<li ><a href='index.php?sayfa=teklif_mesaj&page=$sonraki'><div class='fa fa-chevron-right'></div></a></li> ";
   }
endif;  ?> </ul></div></div></div></div></div>
                                    </tbody>
                                </table>
                            </div>