<script type="text/javascript" src="js/jquery-1.11.2.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>

<div class="row"><div class="col-lg-12"><h1 class="page-header">Anasayfa</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Projeler<div style="float:right;"><a href="<?php echo Site_url;?>/admin/index.php?sayfa=projeler_ekle">Yeni Ekle</a></div></div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped">
						<?php
						$limit = 15;
						$sira=1;
						$page = @$_GET["page"];
						if(empty($page) or !is_numeric($page)) { $page = 1; }
						if($page>1) $sira+=$limit*$page-$limit;
							$count			 = mysql_num_rows(mysql_query("SELECT id FROM projeler"));
							$toplamsayfa	 = ceil($count / $limit);
							$baslangic		 = ($page-1)*$limit;

						$yazdir_sorgu = mysql_query("SELECT * FROM projeler  ORDER BY siralama,id asc LIMIT $baslangic,$limit") or die(mysql_error());
						if(mysql_num_rows($yazdir_sorgu)=="0"){
							if($toplamsayfa == 0 ){ 
								echo '<br><br><br><br><center><h1>Kayıt Bulunamadı...  <div class="fa fa-warning-sign"></div></h1></center><br><br><br><br>'; 
							}else{
								if($page > $toplamsayfa) echo '<script language="javascript">location.href="index.php?sayfa=projeler";</script>';
							}
						}else{
						?>
						<thead><tr><th>#</th><th>Proje Adı</th><th>Düzenle</th></tr></thead>
						<tbody id="sortable"> 
						<?php
						while ($gelen = mysql_fetch_array($yazdir_sorgu)){    ?>
							<tr id="item-<?php echo $gelen["id"];?>">
								<td class="sortable"><?php echo "<b>".$sira."<b>"; $sira++; ?></td>
								<td style="width:400px;"><?php echo $gelen['proje_adi']; ?></td> 
								<td><a href="<?php echo Site_url;?>/admin/index.php?sayfa=projeler_duzenle&id=<?php echo $gelen["id"];?>"><p class="fa fa-edit"></p></a> <a href="<?php echo Site_url;?>/admin/index.php?sayfa=projeler_sil&id=<?php echo $gelen["id"];?>"><p class="fa fa-remove"></p></a></td>
							</tr>
						<?php }  } ?>
						</tbody>
					</table>
					<div class="bs-example">
						<ul class="pagination pagination-lg">
						<?php
						 if($count > $limit) :
							  $x = 2;
							  $lastP = ceil($count/$limit);
							  if($page > 1){
							  $onceki = $page-1;
							  echo "<li ><a  href='index.php?sayfa=projeler&page=$onceki'><div class='fa fa-chevron-left'></div></a></li> ";
						  }
						  if($page==1) echo "  <li class='active'><a >1</a></li>";
						  else  echo "  <li><a href='index.php?sayfa=projeler'>1</a></li>";
						  if($page-$x > 2) {
							  echo "  <li><a>...</a></li> ";
							  $i = $page-$x;
						  } else {
							$i = 2;
						  }
						  for($i; $i<=$page+$x; $i++) {
						   if($i==$page) echo "<li  class='active'><a href='index.php?sayfa=projeler&page=$i'>$i</a></li>";
						   else echo "<li ><a href='index.php?sayfa=projeler&page=$i'>$i</a></li>";
						   if($i==$lastP) break;
						  }
						  if($page+$x < $lastP-1) {
						   echo "  <li><a>...</a> <a  href='index.php?sayfa=projeler&page=$lastP'>$lastP</a></li> ";

						  } elseif($page+$x == $lastP-1) {
								echo "<li ><a  href='index.php?sayfa=projeler&page=$lastP'>$lastP</a></li> ";
						  }
						  if($page < $lastP){
							$sonraki = $page+1;
							echo "<li ><a href='index.php?sayfa=projeler&page=$sonraki'><div class='fa fa-chevron-right'></div></a></li> ";
						   }
						endif;  ?> 
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<style type="text/css">
	.sortable { cursor: move; }
</style>
<script type="text/javascript">
$(function() {
	$( "#sortable" ).sortable({
		revert: true,
		handle: ".sortable",
		stop: function (event, ui) {
			var data = $(this).sortable('serialize');

			$.ajax({
				type: "POST",
				dataType: "json",
				data: data,
				url: "sirala.php?p=urunSirala",
				success: function(msg){
					alert( msg.urunSiralaIslemMsj );
				}
			});	                      				
		}
	});
	$( "#sortable" ).disableSelection();	                      		
});	                      	
</script>	

