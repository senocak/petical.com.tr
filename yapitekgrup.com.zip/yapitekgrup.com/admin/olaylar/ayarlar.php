<?php
$ayarlar=mysql_fetch_object(mysql_query("select * from ayarlar"));
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Ayarlar</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Ayarlar</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Site Başlığı </td><td><input required type="text" name="title" value="<?php echo $ayarlar->title; ?>" class="form-control"/></td></tr>
							<tr><td>Site Footer </td><td><input required  type="text" name="footer" value="<?php echo $ayarlar->footer; ?>" class="form-control"/></td></tr>
							<tr><td>Telefon</td><td><input required  type="text" name="telefon" value="<?php echo $ayarlar->telefon; ?>" class="form-control"/></td></tr>
							<tr><td>Site Url</td><td><input required  type="text" name="site_url" value="<?php echo $ayarlar->site_url; ?>" class="form-control"/></td></tr>
							<tr><td>Facebook <i class="fa fa-facebook"></i></td><td><input required  type="text" name="facebook" value="<?php echo $ayarlar->facebook; ?>" class="form-control"/></td></tr>
							<tr><td>Twitter <i class="fa fa-twitter"></i></td><td><input required  type="text" name="twitter" value="<?php echo $ayarlar->twitter; ?>" class="form-control"/></td></tr>
							<tr><td>E-Posta  </td><td><input required  type="text" name="email" value="<?php echo $ayarlar->email; ?>" class="form-control"/></td></tr>
							<tr><td>Adres  </td><td><input required  type="text" name="adres" value="<?php echo $ayarlar->adres; ?>" class="form-control"/></td></tr>
							<tr><td>Logo Resmi</td><td><input    type="file" onChange="showimagepreview(this);"  id="exampleInputFile1" class="btn btn-default"  name="logo" id="resim"></td></tr>
							<tr><td></td><td><img  src="images/<?php echo $ayarlar->logo; ?>" width="100px" title="Kayıtlı Resim"> » <img title="Yeni Resim" id="imgview" src="images/bos.jpg"  width="100px" /> </td></td></tr>
							
							<tr><td>Katalog Resmi</td><td><input    type="file" onChange="showimagepreview2(this);"  id="exampleInputFile2" class="btn btn-default"  name="katalog_resmi" id="resim"></td></tr>
							<tr><td></td><td><img  src="images/<?php echo $ayarlar->katalog_resim; ?>" width="100px" title="Kayıtlı Resim"> » <img title="Yeni Resim" id="imgview2" src="images/bos.jpg"  width="100px" /> </td></td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="form-control" value="Gönder"/></td></tr>
						</table>
					</form>
</div></div></div></div></div> 
<?php
if(isset($_POST["gonder"])){
$title = $_POST['title']; 
$footer = $_POST['footer'];
$telefon = $_POST['telefon'];
$site_url = $_POST['site_url'];
$facebook = $_POST['facebook'];
$twitter = $_POST['twitter'];
$email = $_POST['email'];
$adres = $_POST['adres'];
require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
$logo = $_FILES['logo']; // Form'dan yüklenen logo.
$katalog_resmi = $_FILES['katalog_resmi']; // Form'dan yüklenen logo.
if($site_url==""){
	echo "<script>alert('Site Url\'sini girmek zorundasınız!..');</script>"; 
}else{
if($logo["name"]!=""){
$yukle = new upload($logo); //Sınıfımızı Başlatıyoruz.
$klasor = 'images'; //Resmin Yükleneceği Klasör
	if ($yukle->uploaded){
		$yukle->file_new_name_body = "logo"; 
		$yukle->image_resize          = true;
		$yukle->image_ratio_fill      = true;
		$yukle->image_x               = 299;
		$yukle->image_y               = 55;
		$yukle->process($klasor);
			if($yukle->processed) {
			$banner_sil=mysql_fetch_object(mysql_query("select * from ayarlar"));
			unlink("images/".$banner_sil->logo); 
			$logo_update=mysql_query("UPDATE ayarlar SET  logo='$yukle->file_dst_name'");
				if($logo_update){
					echo '<script>alert("Logo Güncellendi");</script>";</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
				}else{
					echo '<script>alert("Logo Güncellenmedi");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
					$yukle->clean();
				}
			}else{
				echo '<script>alert("Logo Güncellenmedi");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
			}
	}
}
if($katalog_resmi["name"]!=""){
$yukle2 = new upload($katalog_resmi); //Sınıfımızı Başlatıyoruz.
$klasor = 'images'; //Resmin Yükleneceği Klasör
	if ($yukle2->uploaded){
		$yukle2->file_new_name_body = "katalog"; 
		$yukle2->image_resize          = true;
		$yukle2->image_ratio_fill      = true;
		$yukle2->image_x               = 480;
		$yukle2->image_y               = 270;
		$yukle2->process($klasor);
			if($yukle2->processed) {
			$banner_sil=mysql_fetch_object(mysql_query("select * from ayarlar"));
			unlink("images/".$banner_sil->katalog_resim); 
			$katalog_resmi_update=mysql_query("UPDATE ayarlar SET  katalog_resim='$yukle2->file_dst_name'");
				if($katalog_resmi_update){
					echo '<script>alert("Katalog Resmi Güncellendi");</script>";</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
				}else{
					echo '<script>alert("Katalog Resmi Güncellenmedi");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
					$yukle2->clean();
				}
			}else{
				echo '<script>alert("Katalog Resmi Güncellenmedi2");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
			}
	}
}
		$update=mysql_query("UPDATE ayarlar SET  title='$title',footer='$footer',telefon='$telefon',site_url='$site_url',facebook='$facebook',twitter='$twitter',email='$email',adres='$adres',google_map='$google_map'");
			if($update)echo "<script>alert('Güncelleme Başarılı...');</script>"; 
			else echo "<script>alert('Güncelleme Başarısız!..".mysql_error()."');</script>"; 
			echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=ayarlar';</script>";
}
}