<div class="row"><div class="col-lg-12"><h1 class="page-header">Kurumsal</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Kurumsal</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<form enctype="multipart/form-data"  method="post">
						<table class="table table-striped">
							<tr><td>Başlık</td><td><input required  type="text" name="baslik" placeholder="Hizmetlerimiz Başlık" class="form-control"/></td></tr>
							<tr><td>Açıklama</td><td><textarea required  style="resize:vertical;" class="ckeditor" name="aciklama" class="form-control"> </textarea></td></tr>
							<tr><td>Resim Kırpma</td><td> 
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline1" value="1" type="radio">Resim Kırpılsın</label>
								<label class="radio-inline"><input required  name="kırp" id="optionsRadiosInline2" value="0" checked="" type="radio">Resim Kırpılmasın</label>  
							</td></tr> 
							<tr><td>Resim Ekle</td><td><input type="file" onChange="showimagepreview(this);"  id="exampleInputFile1"  class="btn btn-default"  name="resim" id="resim"></td></tr>
							<tr><td></td><td><img title="Yeni Resim" id="imgview" src="<?php echo Site_url;?>/admin/images/bos.jpg"  width="100px" /> </td></tr>
							<tr><td></td><td><input type="submit" name="gonder" class="btn btn-outline btn-primary btn-lg btn-block" class="form-control" value="Gönder"/></td></tr>
						</table>
					</form>
</div></div></div></div></div>
<?php
if(isset($_POST["gonder"])){ 
$baslik = $_POST['baslik']; 
$aciklama = $_POST['aciklama']; 
$kırp = $_POST['kırp'];  
require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
$resim = $_FILES['resim']; // Form'dan yüklenen resim.
$yukle = new upload($resim); //Sınıfımızı Başlatıyoruz.
$klasor = 'images/hizmetlerimiz'; //Resmin Yükleneceği Klasör 
$url=kucuk(url_duzenle($baslik));
$toplam=mysql_num_rows(mysql_query("select * from hizmetlerimiz"));
if($resim["name"]!=""){
		if ($yukle->uploaded){
		if($kırp==1){
			$yukle->image_resize          = true;
			$yukle->image_ratio_fill      = true;
			$yukle->image_x               = 700;
			$yukle->image_y               = 520;
		}
		//$yukle->file_new_name_body = $url;
		$yukle->process($klasor);
			if($yukle->processed) {
			$update=mysql_query("insert into hizmetlerimiz (baslik,aciklama,siralama,resim) values ('$baslik','$aciklama','$toplam','$yukle->file_dst_name')");
				if($update){
					echo '<script>alert("Ekleme Başarılı");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
				}else{
					echo '<script>alert("Ekleme Başarısız");</script>';
					echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
					$yukle->clean();
				}
			}else{
				echo '<script>alert("Ekleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
			}
	}
	}else{
		$update=mysql_query("insert into hizmetlerimiz (baslik,aciklama,siralama) values ('$baslik','$aciklama','$toplam')");
			if($update){
				echo '<script>alert("Ekleme Başarılı");</script>";</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
			}else{
				echo '<script>alert("Ekleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=hizmetlerimiz';</script>";
				$yukle->clean();
			}
	}
}