<?php
$id=$_GET["id"];
$teklif_mesaj = mysql_fetch_object(mysql_query("select * from mesaj where id='$id'"));
if(isset($teklif_mesaj->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=teklif_mesaj";</script>';;
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Mesajlar</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Mesajlar</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<table>
					<tr><td>Ad Soyad</td><td>:</td><td> </td><td><input type="text" readonly style="width:100%;" name="baslik" value="<?php echo $teklif_mesaj->isim; ?>" class="form-control" /></td></tr>
					<tr><td>E-Posta</td><td>:</td><td> </td><td><input type="text" readonly style="width:100%;" name="baslik" value="<?php echo $teklif_mesaj->email; ?>" class="form-control" /></td></tr>
					<tr><td>İçerik</td><td>:</td><td> </td><td><textarea disabled class="ckeditor"  name="icerik" ><?php echo $teklif_mesaj->mesaj; ?></textarea></td></tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php