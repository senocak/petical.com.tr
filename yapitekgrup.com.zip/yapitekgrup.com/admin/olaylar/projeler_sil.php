<?php
$id = $_GET['id'];
echo $id;
$projeler = mysql_fetch_object(mysql_query("select * from projeler where id='$id'"));
if(isset($projeler->id)) echo ""; else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=projeler";</script>';
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Proje</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Projeler</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<center>
					<h2>Silmek İstediğinize Emin Misiniz?</h2><br><br>	<form method="post">
					<input class="btn btn-success btn-lg"   type="submit" value="Evet" name="sil">
					<input class="btn btn-danger btn-lg"   type="submit" value="Hayır" name="silme">   </form>
					</center> 
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	if(isset($_POST["sil"])){
		$sil_sorgu=mysql_query("select * from projeler_resim where proje_id='$id'");
		while($sil=mysql_fetch_object($sil_sorgu)){
			unlink("images/proje_resimler/$sil->url");
		}
		$del  = mysql_query("delete from projeler_resim where proje_id='$id'");
		$del  = mysql_query("delete from projeler where id='$id'");
		echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=projeler";</script>'; 
	}
	if(isset($_POST["silme"])){
	echo '<script type="text/javascript">history.go(-2)</script>';
	}
