<?php
$id=$_GET["id"];
$referans = mysql_fetch_object(mysql_query("select * from projeler where id='$id'"));
if(isset($referans->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=projeler";</script>';;
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">projeler</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">projeler</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<form method="post" enctype="multipart/form-data"> <table>
					<tr><td>Proje İsmi</td><td>:</td><td> </td><td><input type="text" style="width:100%;" name="proje_ismi" value="<?php echo $referans->proje_adi; ?>" class="form-control" /></td></tr>
					<tr><td>Proje Özellikleri</td><td>:</td><td> </td><td><textarea name="proje_ozellikleri" class="ckeditor"><?php echo $referans->proje_ozellikleri; ?></textarea></td></tr>
					<tr><td></td><td></td><td></td><td><br><input type="submit" class="btn btn-primary" name="gonder1" style="width:200px;" value="Güncelle" /><div class="fa fa-refresh"></div></td></tr>
					</table> </form>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">projeler</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<form method="post" enctype="multipart/form-data"><table>
					<tr><td>Resim Ekle</td>
					<td><input type="file" onChange="showimagepreview(this);"  id="exampleInputFile1"  class="btn btn-default"  name="resim" id="resim"></td>
					<td><img title="Yeni Resim" id="imgview" src="images/bos.jpg"  width="100px" /></td></tr>
					<?php 
					$resim_sorgu=mysql_query("select * from projeler_resim where proje_id='$id'");
					while($resim_yaz=mysql_fetch_object($resim_sorgu)){
						echo "<tr><td><img src='".Site_url."/admin/images/proje_resimler/".$resim_yaz->url."' width='20%'></td><td><a href='".Site_url."/admin/index.php?sayfa=projeler_resim_sil&id=$resim_yaz->id'><p class='fa fa-remove'></p></a></td><td></td></tr>";
					}
					?>
					<tr><td><input type="submit" class="btn btn-primary" name="gonder2" style="width:200px;" value="Kaydet"/><div class="fa fa-refresh"></div></td><td></td><td></td></tr>
					</table></form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
$aa = mysql_fetch_array(mysql_query("select * from projeler where id='$id'"));
if(isset($_POST["gonder1"])){
	$proje_ismi = $_POST['proje_ismi'];
	$proje_ozellikleri = $_POST['proje_ozellikleri'];
	$url=kucuk(url_duzenle($proje_ismi));
	if($aa["proje_adi"]!= $proje_ismi || $aa["proje_ozellikleri"]!= $proje_ozellikleri ){
		$baslik_update=mysql_query("UPDATE projeler SET  proje_adi='$proje_ismi',proje_ozellikleri='$proje_ozellikleri',proje_url='$url' where id='$id'");
		echo '<script>alert("Düzenleme Başarılı");</script>';
		echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler_duzenle&id=$id';</script>";
	}
}
if(isset($_POST["gonder2"])){
	require_once ('class.upload.php'); // Class ' ımızı dahil ediyoruz.
	$resim = $_FILES['resim']; // Form'dan yüklenen resim.
	$yukle = new upload($resim); //Sınıfımızı Başlatıyoruz.
	$klasor = 'images/proje_resimler'; //Resmin Yükleneceği Klasör 
	if ($yukle->uploaded){
		$yukle->image_resize          = true;
		$yukle->image_ratio_fill      = true;
		$yukle->image_x               = 730;
		$yukle->image_y               = 450;
		$yukle->process($klasor);
		
		if($yukle->processed) {
			$insert=mysql_query("insert into projeler_resim (proje_id,url) values ('$id','$yukle->file_dst_name')");
			
			if($insert){
				echo '<script>alert("Düzenleme Başarılı");</script>";</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler_duzenle&id=$id';</script>";
			}else{
				echo '<script>alert("Düzenleme Başarısız");</script>';
				echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler_duzenle&id=$id';</script>";
				$yukle->clean();
			}
		}else{
			echo '<script>alert("Düzenleme Başarısız");</script>';
			echo "<script language='javascript'>location.href='".Site_url."/admin/index.php?sayfa=projeler_duzenle&id=$id';</script>";
		}
	}
}