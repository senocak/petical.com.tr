<?php
$id = $_GET['id'];
$kurumsal = mysql_fetch_object(mysql_query("select * from kurumsal where id='$id'"));
if(isset($kurumsal->id)) echo "";else echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=kurumsal";</script>';
if($id==1) echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=kurumsal";</script>'; 
?>
<div class="row"><div class="col-lg-12"><h1 class="page-header">Kurumsal</h1></div></div>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Kurumsal</div> 
			<div class="panel-body">
				<div class="table-responsive">
					<center>
					<h2>Silmek İstediğinize Emin Misiniz?</h2><br><br>	<form method="post">
					<input class="btn btn-success btn-lg" type="submit" value="Evet" name="sil">
					<input class="btn btn-danger btn-lg" type="submit" value="Hayır" name="silme">   </form>
					</center> 
				</div>
			</div>
		</div>
	</div>
</div>
<?php
if(isset($_POST["sil"])){
	$sil=mysql_fetch_object(mysql_query("select * from kurumsal where id='$id'"));
	$del  = mysql_query("delete from kurumsal where id='$id'");
	if($sil->resim!="bos.jpg"){ 
		unlink("images/kurumsal_resimler/$sil->resim");
	}
	echo '<script type="text/javascript">location.href="'.Site_url.'/admin/index.php?sayfa=kurumsal";</script>'; 
}

if(isset($_POST["silme"])){
	echo '<script type="text/javascript">history.go(-2)</script>';
}