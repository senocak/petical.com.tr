<?php
include('../config.php');
if ( isset($_GET['p']) ){
	if ( $_GET['p'] == 'urunSirala' ){
		if ( is_array($_POST['item']) ){		
			foreach ( $_POST['item'] as $key => $value ){
				mysql_query("UPDATE projeler SET siralama = '$key' WHERE id ='$value'");				
			}
			$urunSiralaMsg = array( 'islemSonuc' => true , 'urunSiralaIslemMsj' => 'İçeriklerin sıralama işlemi güncellendi' );
		} else {
			$urunSiralaMsg = array( 'islemSonuc' => false ,'urunSiralaIslemMsj' => 'İçeriklerin sıralama işleminde hata oluştu' );
		}
	}
if ( isset($urunSiralaMsg) ){
	echo json_encode($urunSiralaMsg);
}
	
	if ( $_GET['p'] == 'kurumsalSirala' ){
		if ( is_array($_POST['item']) ){		
			foreach ( $_POST['item'] as $key => $value ){
				mysql_query("UPDATE kurumsal SET siralama = '$key' WHERE id ='$value'");				
			}
			$kurumsalSiralaMsg = array( 'islemSonuc' => true , 'kurumsalSiralaIslemMsj' => 'İçeriklerin sıralama işlemi güncellendi' );
		} else {
			$kurumsalSiralaMsg = array( 'islemSonuc' => false ,'kurumsalSiralaIslemMsj' => 'İçeriklerin sıralama işleminde hata oluştu' );
		}
	}
if ( isset($kurumsalSiralaMsg) ){
	echo json_encode($kurumsalSiralaMsg);
}
	
	if ( $_GET['p'] == 'ekibimizSirala' ){
		if ( is_array($_POST['item']) ){		
			foreach ( $_POST['item'] as $key => $value ){
				mysql_query("UPDATE ekibimiz SET siralama = '$key' WHERE id ='$value'");				
			}
			$ekibimizSiralaMsg = array( 'islemSonuc' => true , 'ekibimizSiralaIslemMsj' => 'Ekibimiz sıralaması güncellendi' );
		} else {
			$ekibimizSiralaMsg = array( 'islemSonuc' => false ,'ekibimizSiralaIslemMsj' => 'Ekibimiz sıralama işleminde hata oluştu' );
		}
	}
if ( isset($ekibimizSiralaMsg) ){
	echo json_encode($ekibimizSiralaMsg);
}

	
	if ( $_GET['p'] == 'hizmetlerimizSirala' ){
		if ( is_array($_POST['item']) ){		
			foreach ( $_POST['item'] as $key => $value ){
				mysql_query("UPDATE hizmetlerimiz SET siralama = '$key' WHERE id ='$value'");				
			}
			$hizmetlerimizSiralaMsg = array( 'islemSonuc' => true , 'hizmetlerimizSiralaIslemMsj' => 'Hizmetlerimiz sıralaması güncellendi' );
		} else {
			$hizmetlerimizSiralaMsg = array( 'islemSonuc' => false ,'hizmetlerimizSiralaIslemMsj' => 'Hizmetlerimiz sıralama işleminde hata oluştu' );
		}
	}
if ( isset($hizmetlerimizSiralaMsg) ){
	echo json_encode($hizmetlerimizSiralaMsg);
}


}
?>