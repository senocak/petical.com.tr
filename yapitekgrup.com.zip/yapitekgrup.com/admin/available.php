<?php
include("../config.php");
if(isset($_POST['action']) && $_POST['action'] == 'availability'){
	$username       = mysql_real_escape_string($_POST['username']);
	$count  = mysql_num_rows(mysql_query("select kullanici_adi from admin where kullanici_adi='$username'"));
	echo $count;
}
?>