<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include("../config.php"); 
$durum="";
$durum = isset($_SESSION['username']) ? $_SESSION['username'] : ""; 
if($durum =="") echo '<script language="javascript">location.href="login.php";</script>';
$sayfa="";
$sayfa=isset($_GET["sayfa"]) ? $_GET["sayfa"] : ""; 

$ayarlar=mysql_fetch_object(mysql_query("select * from ayarlar"));

//echo $sayfa;

 
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="copyright" content="Bilgimedya Yazılım, Tasarım" />
<meta name="author" content="Bilgimedya Yazılım, Tasarım" /> 
    <meta name="author" content=""> 

<link rel="shortcut icon" href="images/favicon.png"> 
    <title>Yapıtek Proje Grubu / Mühendislik & Mimarlık </title>

    <link href="ckeditor/ckeditor.css" rel="stylesheet">
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<script>
        CKEDITOR.replace( 'editor', {
            //filebrowserUploadUrl: 'db.php?upload_img',
            extraPlugins: 'image2,imageuploader',
            language: 'tr'
        } );
    </script>
	
    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
	function showimagepreview(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('#imgview').attr('src', e.target.result);
				}
			reader.readAsDataURL(input.files[0]);
			}
	}
</script>
<script type="text/javascript">
	function showimagepreview2(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$('#imgview2').attr('src', e.target.result);
				}
			reader.readAsDataURL(input.files[0]);
			}
	}
</script>
</head>
<body>
    <div id="wrapper"> 
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo Site_url;?>/admin/index.php">Yapıtek Proje Grubu / Mühendislik & Mimarlık</a>
            </div> 

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
					<?php 
					$top_mesaj_sorgu=mysql_query("select * from mesaj where okundu='0' limit 0,3 ");
					while($top_mesaj_yaz=mysql_fetch_object($top_mesaj_sorgu)){
						if(strlen($top_mesaj_yaz->mesaj)>=50){ 
							if(preg_match('/(.*?)\s/i',substr($top_mesaj_yaz->mesaj,50),$dizi))$top_mesaj_yaz->mesaj=substr($top_mesaj_yaz->mesaj,0,50+strlen($dizi[0]))."...";  
						}else{
							$top_mesaj_yaz->mesaj .="";
						}
						echo '<li>
                            <a href="'.Site_url.'/admin/index.php?sayfa=teklif_mesaj_oku&id='.$top_mesaj_yaz->id.'">
                                <div><strong>'.$top_mesaj_yaz->isim.'</strong><span class="pull-right text-muted"><em>'.$top_mesaj_yaz->tarih.'</em></span></div>
                                <div>'.$top_mesaj_yaz->mesaj.'</div>
                            </a>
                        </li>
                        <li class="divider"></li>';
					}
					?>
                        <li><a class="text-center" href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj"><strong>Tüm Mesajları Oku</strong><i class="fa fa-angle-right"></i></a></li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li> 
				
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i></a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo Site_url;?>/admin/index.php?sayfa=profil"><i class="fa fa-user fa-fw"></i>Profil</a></li>
                        <li><a href="<?php echo Site_url;?>/admin/index.php?sayfa=ayarlar"><i class="fa fa-gear fa-fw"></i>Ayarlar</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo Site_url;?>/admin/index.php?sayfa=logout" onclick="return confirm('Çıkmak İstediginize Emin Misiniz');"><i class="fa fa-sign-out fa-fw"></i> Logout</a></li>
                    </ul>
                </li>
				
            </ul>
			
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search..."/>
                                <span class="input-group-btn"><button class="btn btn-default" type="button"><i class="fa fa-search"></i></button></span>
                            </div> 
                        </li>
                        <li <?php if($sayfa=="") echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php"><i class="fa fa-dashboard fa-fw"></i> Anasayfa</a></li>
                        <li <?php if($sayfa=="kurumsal" or $sayfa=="kurumsal_duzenle") echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=kurumsal"><i class="fa fa-group"></i> Kurumsal</a></li> 
                        <li <?php if(($sayfa=="hizmetlerimiz") or ($sayfa=="hizmetlerimiz_duzenle") or ($sayfa=="hizmetlerimiz_ekle") or ($sayfa=="hizmetlerimiz_sil")) echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=hizmetlerimiz"><i class="fa fa-file"></i> Hizmetlerimiz</a></li>
                        <li <?php if(($sayfa=="ekibimiz") or ($sayfa=="ekibimiz_duzenle") or ($sayfa=="ekibimiz_ekle") or ($sayfa=="ekibimiz_sil")) echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=ekibimiz"><i class="fa fa-user"></i> Ekibimiz</a></li>
                        <li <?php if($sayfa=="projeler") echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=projeler"><i class="fa fa-camera-retro "></i> Projeler</a></li> 
                        <li <?php if($sayfa=="teklif_mesaj" or $sayfa=="teklif_mesaj_icerik") echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=teklif_mesaj"><i class="fa fa-envelope-o "></i> Teklifler / Mesajlar</a></li>
                        <li <?php if($sayfa=="ayarlar") echo 'style="background-color: rgb(221, 216, 216);"';?>><a href="<?php echo Site_url;?>/admin/index.php?sayfa=ayarlar"><i class="fa fa-anchor"></i> Ayarlar</a></li>
                    </ul>
                </div>
				
				<b>Duyuru : </b>
				<br> <i class="fa fa-star fa-fw"></i>Resim Boyutlandırma Özelliği Aktif
				<br> <i class="fa fa-star fa-fw"></i>Hizmetlerimiz Açılır Menü Aktif
				<br> <i class="fa fa-star fa-fw"></i>Ekibimiz Açılır Menü Aktif
				<br> <i class="fa fa-star fa-fw"></i>Sürükle Bırak Özelliği Aktif
				
				
            </div>
        </nav>
        <div id="page-wrapper"> 
			<?php 
			if($sayfa=="")$sayfa="anasayfa";
			if($sayfa=="kurumsal")$sayfa="anasayfa";
			include("olaylar/".$sayfa.".php");
			
			/*
			switch($sayfa){
				case "":
				case "kurumsal": 
				default:
					include("olaylar/anasayfa.php"); // Kurumsal ve Anasayfa Aynı
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "kurumsal_duzenle":
					include("olaylar/kurumsal_duzenle.php"); 
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "kurumsal_ekle":  
					include("olaylar/kurumsal_ekle.php"); 
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "kurumsal_sil":  
					include("olaylar/kurumsal_sil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "projeler": 
					include("olaylar/projeler.php"); 
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "projeler_ekle":  
					include("olaylar/projeler_ekle.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "projeler_duzenle":
					include("olaylar/projeler_duzenle.php"); 
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "projeler_resim_sil":
					include("olaylar/projeler_resim_sil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "projeler_sil":
					include("olaylar/projeler_sil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "teklif_mesaj":  
					include("olaylar/teklif_mesaj.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "teklif_mesaj_durum":
					include("olaylar/teklif_mesaj_oku.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "ekibimiz":
					include("olaylar/ekibimiz.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "ekibimiz_duzenle":
					include("olaylar/ekibimiz_duzenle.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "ekibimiz_sil":
					include("olaylar/ekibimiz_sil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "ekibimiz_ekle":
					include("olaylar/ekibimiz_ekle.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "teklif_mesaj_sil":
					include("olaylar/teklif_mesaj_sil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "teklif_mesaj_oku":
					include("olaylar/teklif_mesaj_icerik.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "profil":  
					include("olaylar/profil.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "ayarlar": 
					include("olaylar/ayarlar.php");
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
				case "logout":
					session_destroy();
					echo '<meta http-equiv="refresh" content="0;URL='.Site_url.'admin/login.php">';
					echo "<script language='javascript'>location.href='".Site_url."/admin/login.php';</script>";
				break;
				////////////////////////////////////////////////////////////////////////////////////////////
		}*/
			?>
			 </div>
			 
		<script src="js/jquery-1.11.2.js" type="text/javascript"></script>
		<script type="text/javascript" src="js/jquery-ui.js"></script>
			 
			 
    <!-- jQuery -->
				<!--<script src="bower_components/jquery/dist/jquery.min.js"></script> -->
    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!-- Morris Charts JavaScript -->
    <script src="bower_components/raphael/raphael-min.js"></script>
    <script src="bower_components/morrisjs/morris.min.js"></script>
    <script src="js/morris-data.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
</body>
</html>