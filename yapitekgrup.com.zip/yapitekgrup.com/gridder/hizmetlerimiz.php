<link href="<?php echo Site_url;?>/gridder/js/bootstrap-portfilter.min.js" rel="stylesheet">
		<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
	<div class="container" style="margin-left: 40px; font-family:Helvetica; color:#A7A2A2;"><h1><?php echo $hizmetler;?></h1></div>

<!-- Le styles -->
		<link href="<?php echo Site_url;?>/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">

		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<style>
			html, body {
				height: 100%;
			}
			.wrapper {
				min-height: 100%;
				height: auto !important;
				height: 100%;
				margin: 0 auto -120px;
			}
			.footer, .push {
				height: 120px;
			}
		</style>

<div class="container wrapper" style="margin-left: 40px; width: 120%;"> 
	<ul class="thumbnails gallery">
	<?php
	$ekip_sorgu=mysql_query("select * from hizmetlerimiz order by siralama asc");
	while($ekip_yaz=mysql_fetch_object($ekip_sorgu)){ ?>  
		<li class="span3 clearfix" >
			<div class="thumbnail" style="height:280px; width: 90%;">
			<?php echo 	"<img src='".Site_url."/admin/images/hizmetlerimiz/$ekip_yaz->resim' />"; ?>
				<div class="caption"><h5><?php echo $ekip_yaz->baslik ;?></h5><h6><? echo $ekip_yaz->unvan; ?></h6></div>
			</div>
		</li>
		<?php } ?>
	</ul>
	<div class="push"></div>
</div>