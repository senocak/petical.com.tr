-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 22 Haz 2016, 18:14:23
-- Sunucu sürümü: 5.6.14
-- PHP Sürümü: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `yapitekgrup.com`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(100) NOT NULL,
  `sifre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `kullanici_adi`, `sifre`) VALUES
(1, 'anil', '71b9b5bc1094ee6eaeae8253e787d654');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_bin NOT NULL,
  `site_url` varchar(100) COLLATE utf8_bin NOT NULL,
  `adres` text COLLATE utf8_bin NOT NULL,
  `telefon` text COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `facebook` varchar(100) COLLATE utf8_bin NOT NULL,
  `twitter` varchar(100) COLLATE utf8_bin NOT NULL,
  `logo` text COLLATE utf8_bin NOT NULL,
  `katalog_resim` varchar(100) COLLATE utf8_bin NOT NULL,
  `footer` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `title`, `site_url`, `adres`, `telefon`, `email`, `facebook`, `twitter`, `logo`, `katalog_resim`, `footer`) VALUES
(1, 'Yapıtek Proje Grubu / Mühendislik & Mimarlık Mersin', 'http://localhost/yapitekgrup.com', 'Yeni mah. Yüksek Harman Caddesi Aros 9 Apt. alti Mezitli / Mersin', '0-324-333-33-33', 'bilgi@yapitek.com', 'https://www.facebook.com/profile.php?id=100002227143223', 'https://twitter.com/worgil', 'logo.png', 'katalog.jpg', 'Copyright 2015.All Rights Reserved');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik_tr` varchar(100) COLLATE utf8_bin NOT NULL,
  `baslik_en` varchar(100) COLLATE utf8_bin NOT NULL,
  `resim` varchar(100) COLLATE utf8_bin NOT NULL,
  `icerik_tr` mediumtext COLLATE utf8_bin NOT NULL,
  `icerik_en` mediumtext COLLATE utf8_bin NOT NULL,
  `url` varchar(100) COLLATE utf8_bin NOT NULL,
  `tarih` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`id`, `baslik_tr`, `baslik_en`, `resim`, `icerik_tr`, `icerik_en`, `url`, `tarih`) VALUES
(2, 'Tr Elastix ile Mesai İçi ve Mesai Dışı Yönetimi', 'En Elastix ile Mesai İçi ve Mesai Dışı Yönetimi', 'ivr-280x300.png', 'tr \n\n	<p>Her işletme 24 saat çalışmadığı için mesai sonrası santralin yönetimi önem kazanıyor. Senaryomuzda mesai içi saatlerde arayan müşterileri IVR ile karşılayacağız. Mesai saatleri dışında ise arayan kişilerin ses kaydını alıp belirtmiş olduğumuz e-posta adresine göndereceğiz.<span id="more-26"></span></p>\n<p>Sırasıyla,</p>\n<ul>\n<li>IVR oluşturacağız.</li>\n<li>Mesai Saatleri için Time Group oluşturacağız.</li>\n<li>Time Condition oluşturacağız. Oluşturduğumuz Time Group zaman aralığında santralin nasıl davranacağını belirleyeceğiz.</li>\n<li>Inbound Routes üzerinden aranan numaramızı oluşturduğumuz Time Conditions’a yönlendireceğiz.</li>\n</ul>\n<p>Bunları yapabilmemiz için 2 adet ses kaydına ihtiyacımız olacak. <strong>Bu ses kayıtları 8000Hz 16 bit mono ve wav formatında olmalı.</strong> İlk ses kaydımız “Erik Holding’e hoşgeldiniz” olabilir. İkinci ses kaydımız “Şu an mesai saatleri dışındayız lütfen sinyal sesinden sonra mesajınızı bırakınız. Size geri dönüş yapacağız.”</p>\n<p><strong>IVR:</strong> Gelen çağrıları karşılayan kuyruğumuz için bir IVR oluşturup ilk ses kaydımızı yükleyelim. IVR kısmında Add IVR komutunu veriyoruz. Name kısmını ben Robot Operator olarak belirliyorum. İstediğiniz bir isim belirtebilirsiniz. Announcement ayarını ilk ses kaydımızı seçiyoruz. (Erik Holding’e hoşgeldiniz) <strong>Enable Direct Dial</strong> seçeneği arayan kişilere dahili tuşlama hakkı verir. Ben böyle bir işlem istemediğim için bu seçeneği seçmiyorum. <strong>Tuşlama bekleseydim Invalid ve Timeout durumlarında istediğim ses kaydını da buradan belirleyebilirdim.</strong> IVR ımızı oluşturduk. Ana numaramızı bu IVR a yönlendirirsek müşterilerimiz bizi aradığında ses kaydımız kendilerini karşılayacaktır.</p>\n<p><img class="aligncenter size-medium wp-image-144" src="http://www.ozererik.com/wp-content/uploads/2014/01/ivr-280x300.png" alt="ivr" height="300" width="280"></p>\n<p>İlk olarak çağrıları karşılayan dahili numaramızın <strong>VoiceMail &amp; Directory</strong> kısmında Status kısmını Enabled yapıyoruz. VoiceMail Password’umuzu belirliyoruz. Email Attachment ve Delete Voicemail ayarlarımızı “yes” olarak ayarlıyoruz. Kaydetme işlemini yapıyoruz. Böylelikle Voice Mail ayarlarımız tamamlanıyor.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/voicemail.png"><img class="aligncenter size-full wp-image-145" src="http://www.ozererik.com/wp-content/uploads/2014/01/voicemail.png" alt="voicemail" height="400" width="763"></a></p>\n<p>Elimizde bulunan iki ses kaydını da <strong>System Recordings</strong> kısmında santralimize Upload ediyoruz.</p>\n<p><strong>VoiceMail Blasting</strong> bölümünde bir Voice Mail grubu oluşturacağız. Description olarak grup adını belirliyoruz. Ben default olarak “telesekreter” şeklinde ayarlıyorum. Audio Label kısmında “Beep Only – No confirmation” seçeneğini seçiyorum. Voice Mail Box List içinde, ilk iş olarak Voice Mail ayarlarını yaptığımı dahili numaramızı görüyorum.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/vmblast.png"><img class="aligncenter size-full wp-image-146" src="http://www.ozererik.com/wp-content/uploads/2014/01/vmblast.png" alt="vmblast" height="287" width="372"></a></p>\n<p><strong>Announcement:</strong> Mesai saatleri dışında çalınacak ses kaydını belirlemek için bir Announcement oluşturmam gerekiyor. Announcement için description olarak “telesekreter” yazıyoruz. Recording kısmında mesai saatleri dışında hangi ses kaydımın çalmasını istiyorsam o ses kaydını seçiyorum. Repeat ayarı disable olarak kalıyor. Tekrarını istemiyoruz. Destination after playback ayarımızı oluşturduğumuz VoiceMail Blasting’e linkliyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/anons.png"><img class="aligncenter size-full wp-image-147" src="http://www.ozererik.com/wp-content/uploads/2014/01/anons.png" alt="anons" height="370" width="317"></a></p>\n<p><strong>Time Group:</strong> Add Time Group komutunu veriyoruz. Description kısmını mesai olarak ayarlayabiliriz. Ben mesai saatlerini hafta içi 07:00 – 21:00 olarak belirledim. <strong>Farkındayım uçuk bir mesai <img class="wp-smiley" src="http://www.ozererik.com/wp-includes/images/smilies/icon_smile.gif" alt=":)"></strong></p>\n<ul>\n<li><strong>Time to Start:</strong> 07:00</li>\n<li><strong>Time to Finish:</strong> 21:00</li>\n<li><strong>Weekday Start:</strong> Monday</li>\n<li><strong>Weekday End:</strong> Friday</li>\n</ul>\n<p>Şeklinde parametreleri belirliyor ve Time Group ayarlamasını yapıyorum. Burada yeni ve farklı zamanlar oluşturabilir, senaryolar üretebilirsiniz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/timegroup.png"><img class="aligncenter size-full wp-image-148" src="http://www.ozererik.com/wp-content/uploads/2014/01/timegroup.png" alt="timegroup" height="426" width="344"></a></p>\n<p><strong>Time Condition:</strong> Add Time Condition ile oluşturduğumuz mesai saatlerinde yapılacak işleri belirleyeceğiz. Description kısmını mesai-saatleri olarak belirliyorum. <strong>Destination if time matches</strong> kısmında, yani şartlar gerçekleştiğinde olmasını istediğimiz olayı, oluşturduğumuz IVR’ımızı seçiyoruz. Böylelikle mesai saatleri içinde arandığımızda IVR’ımız devreye girecek ve kullanıcıları “Erik Holding’e hoşgeldiniz” şeklinde karşılayacaktır.</p>\n<p><strong>Destination if time does not match</strong> kısmında ise belirlediğimiz saatler dışında santralimizin davranışını belirliyoruz. List box içinden <strong>Announcement</strong> ve oluşturduğumuz<strong>telesekreter</strong>’i seçip kayıt işlemini tamamlıyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/timeco.png"><img class="aligncenter size-full wp-image-150" src="http://www.ozererik.com/wp-content/uploads/2014/01/timeco.png" alt="timeco" height="559" width="380"></a></p>\n<p>Son olarak Inbound Routes kısmında ana numaramız üstüne geliyoruz. Set Destination ayarını Time Conditions ve mesai-saatleri olarak belirliyoruz ve işlemimizi tamamlıyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/setdest.png"><img class="aligncenter size-full wp-image-152" src="http://www.ozererik.com/wp-content/uploads/2014/01/setdest.png" alt="setdest" height="172" width="377"></a></p>\n<p>Böylelikle müşterilerimiz belirlediğimiz saatler içinde aradığında hoş geldiniz mesajı ile karşılayıp, mesai saatleri dışında da müşterilerden ses kaydı alıp ilgili e-posta adresine iletmektedir. Müşterimize artık isteği doğrultusunda ihtiyacını belirleyip dönüş yapabiliriz.</p> \n\n \n \n</article>', 'ing <article class="article">\r\n\r\n    <h1 class="title"><a href="http://belgeler.bilgimedya.com.tr/?p=26">Elastix ile Mesai İçi ve Mesai Dışı Yönetimi</a></h1>\r\n\r\n    <div class="line"> \r\n\r\n        <div class="entry-info">\r\n       \r\n            <span class="entry-date"><i class="icon-time"></i>Haziran 1, 2015</span>\r\n            \r\n			            \r\n                <span class="entry-comments">\r\n                    \r\n                    <i class="icon-comments-alt"></i>\r\n                    <a href="http://belgeler.bilgimedya.com.tr/?p=26#respond">No comments</a>                \r\n                </span>\r\n            \r\n			            \r\n            <span class="entry-standard"><i class="icon-edit"></i>Article</span>\r\n        	\r\n			            \r\n        </div>\r\n    \r\n    </div>\r\n\r\n	<p>Her işletme 24 saat çalışmadığı için mesai sonrası santralin yönetimi önem kazanıyor. Senaryomuzda mesai içi saatlerde arayan müşterileri IVR ile karşılayacağız. Mesai saatleri dışında ise arayan kişilerin ses kaydını alıp belirtmiş olduğumuz e-posta adresine göndereceğiz.<span id="more-26"></span></p>\r\n<p>Sırasıyla,</p>\r\n<ul>\r\n<li>IVR oluşturacağız.</li>\r\n<li>Mesai Saatleri için Time Group oluşturacağız.</li>\r\n<li>Time Condition oluşturacağız. Oluşturduğumuz Time Group zaman aralığında santralin nasıl davranacağını belirleyeceğiz.</li>\r\n<li>Inbound Routes üzerinden aranan numaramızı oluşturduğumuz Time Conditions’a yönlendireceğiz.</li>\r\n</ul>\r\n<p>Bunları yapabilmemiz için 2 adet ses kaydına ihtiyacımız olacak. <strong>Bu ses kayıtları 8000Hz 16 bit mono ve wav formatında olmalı.</strong> İlk ses kaydımız “Erik Holding’e hoşgeldiniz” olabilir. İkinci ses kaydımız “Şu an mesai saatleri dışındayız lütfen sinyal sesinden sonra mesajınızı bırakınız. Size geri dönüş yapacağız.”</p>\r\n<p><strong>IVR:</strong> Gelen çağrıları karşılayan kuyruğumuz için bir IVR oluşturup ilk ses kaydımızı yükleyelim. IVR kısmında Add IVR komutunu veriyoruz. Name kısmını ben Robot Operator olarak belirliyorum. İstediğiniz bir isim belirtebilirsiniz. Announcement ayarını ilk ses kaydımızı seçiyoruz. (Erik Holding’e hoşgeldiniz) <strong>Enable Direct Dial</strong> seçeneği arayan kişilere dahili tuşlama hakkı verir. Ben böyle bir işlem istemediğim için bu seçeneği seçmiyorum. <strong>Tuşlama bekleseydim Invalid ve Timeout durumlarında istediğim ses kaydını da buradan belirleyebilirdim.</strong> IVR ımızı oluşturduk. Ana numaramızı bu IVR a yönlendirirsek müşterilerimiz bizi aradığında ses kaydımız kendilerini karşılayacaktır.</p>\r\n<p><img class="aligncenter size-medium wp-image-144" src="http://www.ozererik.com/wp-content/uploads/2014/01/ivr-280x300.png" alt="ivr" height="300" width="280"></p>\r\n<p>İlk olarak çağrıları karşılayan dahili numaramızın <strong>VoiceMail &amp; Directory</strong> kısmında Status kısmını Enabled yapıyoruz. VoiceMail Password’umuzu belirliyoruz. Email Attachment ve Delete Voicemail ayarlarımızı “yes” olarak ayarlıyoruz. Kaydetme işlemini yapıyoruz. Böylelikle Voice Mail ayarlarımız tamamlanıyor.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/voicemail.png"><img class="aligncenter size-full wp-image-145" src="http://www.ozererik.com/wp-content/uploads/2014/01/voicemail.png" alt="voicemail" height="400" width="763"></a></p>\r\n<p>Elimizde bulunan iki ses kaydını da <strong>System Recordings</strong> kısmında santralimize Upload ediyoruz.</p>\r\n<p><strong>VoiceMail Blasting</strong> bölümünde bir Voice Mail grubu oluşturacağız. Description olarak grup adını belirliyoruz. Ben default olarak “telesekreter” şeklinde ayarlıyorum. Audio Label kısmında “Beep Only – No confirmation” seçeneğini seçiyorum. Voice Mail Box List içinde, ilk iş olarak Voice Mail ayarlarını yaptığımı dahili numaramızı görüyorum.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/vmblast.png"><img class="aligncenter size-full wp-image-146" src="http://www.ozererik.com/wp-content/uploads/2014/01/vmblast.png" alt="vmblast" height="287" width="372"></a></p>\r\n<p><strong>Announcement:</strong> Mesai saatleri dışında çalınacak ses kaydını belirlemek için bir Announcement oluşturmam gerekiyor. Announcement için description olarak “telesekreter” yazıyoruz. Recording kısmında mesai saatleri dışında hangi ses kaydımın çalmasını istiyorsam o ses kaydını seçiyorum. Repeat ayarı disable olarak kalıyor. Tekrarını istemiyoruz. Destination after playback ayarımızı oluşturduğumuz VoiceMail Blasting’e linkliyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/anons.png"><img class="aligncenter size-full wp-image-147" src="http://www.ozererik.com/wp-content/uploads/2014/01/anons.png" alt="anons" height="370" width="317"></a></p>\r\n<p><strong>Time Group:</strong> Add Time Group komutunu veriyoruz. Description kısmını mesai olarak ayarlayabiliriz. Ben mesai saatlerini hafta içi 07:00 – 21:00 olarak belirledim. <strong>Farkındayım uçuk bir mesai <img class="wp-smiley" src="http://www.ozererik.com/wp-includes/images/smilies/icon_smile.gif" alt=":)"></strong></p>\r\n<ul>\r\n<li><strong>Time to Start:</strong> 07:00</li>\r\n<li><strong>Time to Finish:</strong> 21:00</li>\r\n<li><strong>Weekday Start:</strong> Monday</li>\r\n<li><strong>Weekday End:</strong> Friday</li>\r\n</ul>\r\n<p>Şeklinde parametreleri belirliyor ve Time Group ayarlamasını yapıyorum. Burada yeni ve farklı zamanlar oluşturabilir, senaryolar üretebilirsiniz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/timegroup.png"><img class="aligncenter size-full wp-image-148" src="http://www.ozererik.com/wp-content/uploads/2014/01/timegroup.png" alt="timegroup" height="426" width="344"></a></p>\r\n<p><strong>Time Condition:</strong> Add Time Condition ile oluşturduğumuz mesai saatlerinde yapılacak işleri belirleyeceğiz. Description kısmını mesai-saatleri olarak belirliyorum. <strong>Destination if time matches</strong> kısmında, yani şartlar gerçekleştiğinde olmasını istediğimiz olayı, oluşturduğumuz IVR’ımızı seçiyoruz. Böylelikle mesai saatleri içinde arandığımızda IVR’ımız devreye girecek ve kullanıcıları “Erik Holding’e hoşgeldiniz” şeklinde karşılayacaktır.</p>\r\n<p><strong>Destination if time does not match</strong> kısmında ise belirlediğimiz saatler dışında santralimizin davranışını belirliyoruz. List box içinden <strong>Announcement</strong> ve oluşturduğumuz<strong>telesekreter</strong>’i seçip kayıt işlemini tamamlıyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/timeco.png"><img class="aligncenter size-full wp-image-150" src="http://www.ozererik.com/wp-content/uploads/2014/01/timeco.png" alt="timeco" height="559" width="380"></a></p>\r\n<p>Son olarak Inbound Routes kısmında ana numaramız üstüne geliyoruz. Set Destination ayarını Time Conditions ve mesai-saatleri olarak belirliyoruz ve işlemimizi tamamlıyoruz.<a href="http://www.ozererik.com/wp-content/uploads/2014/01/setdest.png"><img class="aligncenter size-full wp-image-152" src="http://www.ozererik.com/wp-content/uploads/2014/01/setdest.png" alt="setdest" height="172" width="377"></a></p>\r\n<p>Böylelikle müşterilerimiz belirlediğimiz saatler içinde aradığında hoş geldiniz mesajı ile karşılayıp, mesai saatleri dışında da müşterilerden ses kaydı alıp ilgili e-posta adresine iletmektedir. Müşterimize artık isteği doğrultusunda ihtiyacını belirleyip dönüş yapabiliriz.</p>\r\n<div class="clear"></div><p class="categories"><strong>Categories: </strong><a href="http://belgeler.bilgimedya.com.tr/?cat=1">Uncategorized</a></p><footer class="line"><div class="entry-info"><span class="tags">Tags: <a href="http://belgeler.bilgimedya.com.tr/?tag=elastix-ile-mesai-ici-ve-mesai-disi" rel="tag">Elastix ile Mesai İçi ve Mesai Dışı</a>, <a href="http://belgeler.bilgimedya.com.tr/?tag=elastix-mesai-cizelgesi" rel="tag">elastix mesai çizelgesi</a>, <a href="http://belgeler.bilgimedya.com.tr/?tag=elastix-time-conditions" rel="tag">elastix time conditions</a>, <a href="http://belgeler.bilgimedya.com.tr/?tag=time-condution" rel="tag">time condution</a></span></div></footer>\r\n\r\n\r\n<div class="clear"></div>\r\n\r\n<section class="contact-form">\r\n\r\n							<div id="respond" class="comment-respond">\r\n				<h3 id="reply-title" class="comment-reply-title">Bir Cevap Yazın <small><a rel="nofollow" id="cancel-comment-reply-link" href="/Index.php?p=26#respond" style="display:none;">Cevabı iptal et</a></small></h3>\r\n									<form action="http://belgeler.bilgimedya.com.tr/wp-comments-post.php" method="post" id="commentform" class="comment-form">\r\n																			<p class="comment-notes"><span id="email-notes">E-posta hesabınız yayımlanmayacak.</span> Gerekli alanlar <span class="required">*</span> ile işaretlenmişlerdir</p>							<p class="comment-form-author"><label for="author">İsim <span class="required">*</span></label> <input id="author" name="author" value="" size="30" aria-required="true" required="required" type="text"></p>\r\n<p class="comment-form-email"><label for="email">E-posta <span class="required">*</span></label> <input id="email" name="email" value="" size="30" aria-describedby="email-notes" aria-required="true" required="required" type="text"></p>\r\n<p class="comment-form-url"><label for="url">İnternet sitesi</label> <input id="url" name="url" value="" size="30" type="text"></p>\r\n												<p class="comment-form-comment"><label for="comment">Yorum</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-describedby="form-allowed-tags" aria-required="true" required="required"></textarea></p>						<p class="form-allowed-tags" id="form-allowed-tags">Şu <abbr title="HyperText Markup Language">HTML</abbr> etiketlerini ve özelliklerini kullanabilirsiniz:  <code>&lt;a href="" title=""&gt; &lt;abbr title=""&gt; &lt;acronym title=""&gt; &lt;b&gt; &lt;blockquote cite=""&gt; &lt;cite&gt; &lt;code&gt; &lt;del datetime=""&gt; &lt;em&gt; &lt;i&gt; &lt;q cite=""&gt; &lt;s&gt; &lt;strike&gt; &lt;strong&gt; </code></p>\r\n						<p class="form-submit"><input name="submit" id="submit" class="submit" value="Comment" type="submit"> <input name="comment_post_ID" value="26" id="comment_post_ID" type="hidden">\r\n<input name="comment_parent" id="comment_parent" value="0" type="hidden">\r\n</p>					</form>\r\n							</div><!-- #respond -->\r\n			    \r\n    <div class="clear"></div>\r\n\r\n</section>\r\n</article>', 'tr_elastix_ile_mesai_ici_ve_mesai_disi_yönetimi', '2015-04-17'),
(3, 'Tr Elastix SSH Portunu Değiştirmek', 'En Elastix SSH Portunu Değiştirmek', 'ivr-280x300 - Kopya.png', 'Tr  \n\n	<p>ssh portunu değiştirmek için sunucumuza root ile giriş yaptıktan sonra ;</p>\n<p>nano /etc/ssh/sshd_config komutu ile sshd_config dosyamızı enterladıktan sonra açıyoruz.</p>\n<p>Ardından önümüze gelen editördeki “Port 22″ değerini görüyoruz.<span id="more-24"></span></p>\n<p>Eğer Port 22 nin başında # diez işareti var ise (#Port 22) onu silmemiz gerekiyor. Aksi taktirde çalışmayacaktır. 22 portunu sistemin kullanmadığı bir port ile değiştirip ardından CTRL+O tuşlaması ile kaydedip, CTRL+X tuşlaması ile dosyayı kapatıyoruz. Ve ardından servisleri resetlememiz gerekmektedir.</p>\n<p>Port 22</p>\n<p>#Protocol 2,1</p>\n<p>Protocol 1</p>\n<p>#AddressFamily any</p>\n<p>#ListenAddress 0.0.0.0</p>\n<p>#ListenAddress ::</p>\n<p>Ancak bu işlemi gerçekleştirirken dikkat etmeniz gereken bir nokta var, oda belirtecek olduğunuz portun başka bir servis tarafından kullanılmıyor olması gerekir.</p>\n<p>Servisi yeniden başlatmak için komut satırında ;</p>\n<p>“service sshd restart” Yazmanız yeterlidir.</p>\n<div class="clear"></div> ', 'En <article class="article">\r\n\r\n    <h1 class="title"><a href="http://belgeler.bilgimedya.com.tr/?p=24">Elastix SSH Portunu Değiştirmek</a></h1>\r\n\r\n    <div class="line"> \r\n\r\n        <div class="entry-info">\r\n       \r\n            <span class="entry-date"><i class="icon-time"></i>Haziran 1, 2015</span>\r\n            \r\n			            \r\n                <span class="entry-comments">\r\n                    \r\n                    <i class="icon-comments-alt"></i>\r\n                    <a href="http://belgeler.bilgimedya.com.tr/?p=24#respond">No comments</a>                \r\n                </span>\r\n            \r\n			            \r\n            <span class="entry-standard"><i class="icon-edit"></i>Article</span>\r\n        	\r\n			            \r\n        </div>\r\n    \r\n    </div>\r\n\r\n	<p>ssh portunu değiştirmek için sunucumuza root ile giriş yaptıktan sonra ;</p>\r\n<p>nano /etc/ssh/sshd_config komutu ile sshd_config dosyamızı enterladıktan sonra açıyoruz.</p>\r\n<p>Ardından önümüze gelen editördeki “Port 22″ değerini görüyoruz.<span id="more-24"></span></p>\r\n<p>Eğer Port 22 nin başında # diez işareti var ise (#Port 22) onu silmemiz gerekiyor. Aksi taktirde çalışmayacaktır. 22 portunu sistemin kullanmadığı bir port ile değiştirip ardından CTRL+O tuşlaması ile kaydedip, CTRL+X tuşlaması ile dosyayı kapatıyoruz. Ve ardından servisleri resetlememiz gerekmektedir.</p>\r\n<p>Port 22</p>\r\n<p>#Protocol 2,1</p>\r\n<p>Protocol 1</p>\r\n<p>#AddressFamily any</p>\r\n<p>#ListenAddress 0.0.0.0</p>\r\n<p>#ListenAddress ::</p>\r\n<p>Ancak bu işlemi gerçekleştirirken dikkat etmeniz gereken bir nokta var, oda belirtecek olduğunuz portun başka bir servis tarafından kullanılmıyor olması gerekir.</p>\r\n<p>Servisi yeniden başlatmak için komut satırında ;</p>\r\n<p>“service sshd restart” Yazmanız yeterlidir.</p>\r\n<div class="clear"></div><p class="categories"><strong>Categories: </strong><a href="http://belgeler.bilgimedya.com.tr/?cat=1">Uncategorized</a></p><footer class="line"><div class="entry-info"><span class="tags">Tags: <a href="http://belgeler.bilgimedya.com.tr/?tag=elastix-ssh-portu" rel="tag">elastix ssh portu</a>, <a href="http://belgeler.bilgimedya.com.tr/?tag=ssh-portu" rel="tag">ssh portu</a>, <a href="http://belgeler.bilgimedya.com.tr/?tag=ssh-portu-degistirme" rel="tag">ssh portu değiştirme</a></span></div></footer>\r\n\r\n\r\n<div class="clear"></div>\r\n\r\n<section class="contact-form">\r\n\r\n							<div id="respond" class="comment-respond">\r\n				<h3 id="reply-title" class="comment-reply-title">Bir Cevap Yazın <small><a rel="nofollow" id="cancel-comment-reply-link" href="/Index.php?p=24#respond" style="display:none;">Cevabı iptal et</a></small></h3>\r\n									<form action="http://belgeler.bilgimedya.com.tr/wp-comments-post.php" method="post" id="commentform" class="comment-form">\r\n																			<p class="comment-notes"><span id="email-notes">E-posta hesabınız yayımlanmayacak.</span> Gerekli alanlar <span class="required">*</span> ile işaretlenmişlerdir</p>							<p class="comment-form-author"><label for="author">İsim <span class="required">*</span></label> <input id="author" name="author" value="" size="30" aria-required="true" required="required" type="text"></p>\r\n<p class="comment-form-email"><label for="email">E-posta <span class="required">*</span></label> <input id="email" name="email" value="" size="30" aria-describedby="email-notes" aria-required="true" required="required" type="text"></p>\r\n<p class="comment-form-url"><label for="url">İnternet sitesi</label> <input id="url" name="url" value="" size="30" type="text"></p>\r\n												<p class="comment-form-comment"><label for="comment">Yorum</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-describedby="form-allowed-tags" aria-required="true" required="required"></textarea></p>						<p class="form-allowed-tags" id="form-allowed-tags">Şu <abbr title="HyperText Markup Language">HTML</abbr> etiketlerini ve özelliklerini kullanabilirsiniz:  <code>&lt;a href="" title=""&gt; &lt;abbr title=""&gt; &lt;acronym title=""&gt; &lt;b&gt; &lt;blockquote cite=""&gt; &lt;cite&gt; &lt;code&gt; &lt;del datetime=""&gt; &lt;em&gt; &lt;i&gt; &lt;q cite=""&gt; &lt;s&gt; &lt;strike&gt; &lt;strong&gt; </code></p>\r\n						<p class="form-submit"><input name="submit" id="submit" class="submit" value="Comment" type="submit"> <input name="comment_post_ID" value="24" id="comment_post_ID" type="hidden">\r\n<input name="comment_parent" id="comment_parent" value="0" type="hidden">\r\n</p>					</form>\r\n							</div><!-- #respond -->\r\n			    \r\n    <div class="clear"></div>\r\n\r\n</section>\r\n</article>', 'tr_elastix_ssh_portunu_degistirmek', '2015-04-17');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ekibimiz`
--

CREATE TABLE IF NOT EXISTS `ekibimiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_soyad` varchar(100) NOT NULL,
  `unvan` varchar(100) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `aciklama` mediumtext NOT NULL,
  `siralama` int(11) NOT NULL,
  `cv` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Tablo döküm verisi `ekibimiz`
--

INSERT INTO `ekibimiz` (`id`, `ad_soyad`, `unvan`, `resim`, `aciklama`, `siralama`, `cv`) VALUES
(2, 'İlhan KORKMAZ', 'İnşaat Mühendisi', 'ilhan_korkmaz.jpg', '<p><strong>İlhan KORKMAZ&nbsp;</strong><br />\r\nİnşaat M&uuml;hendisi</p>\r\n', 0, ''),
(3, 'Zehra KORKMAZ', 'Çevre Mühendisi', 'zehra_korkmaz.jpg', '<p><strong>Zehra KORKMAZ&nbsp;</strong><br />\r\n&Ccedil;evre M&uuml;hendisi</p>\r\n', 1, ''),
(4, 'Ercan Taş', 'İnşaat Teknikeri', 'ercan_tas.jpg', '<p><strong>Ercan Taş</strong><br />\r\nİnşaat Teknikeri</p>\r\n', 2, ''),
(9, 'Faik Say', 'Harita Mühendisi', 'faik_say.jpg', '<p><strong>Faik Say</strong><br />\r\nHarita M&uuml;hendisi</p>\r\n', 3, ''),
(10, 'Büşra ZAFER', 'Mimar', 'busra_zafer.jpg', '<p><strong>B&uuml;şra ZAFER&nbsp;</strong><br />\r\nMimar</p>\r\n', 4, ''),
(11, 'Erkut TANER', 'Mimar', 'erkut_taner.jpg', '<p><strong>Erkut TANER&nbsp;</strong><br />\r\nMimar</p>\r\n', 5, ''),
(12, 'Tahsin Ak', 'Teknik Ögretmen', 'tahsin_ak.jpg', '<p><strong>Tahsin Ak</strong><br />\r\nTeknik &Ouml;gretmen</p>\r\n', 6, ''),
(13, 'Gülsüm KAFADAR', 'Mimar', 'gulsum_kafadar.jpg', '<p><strong>G&uuml;ls&uuml;m KAFADAR&nbsp;</strong><br />\r\nMimar</p>\r\n', 7, ''),
(14, 'Korel KOÇ', 'Elektrik Teknikeri', 'korel_koc.jpg', '<p><strong>Korel KO&Ccedil;&nbsp;</strong><br />\r\nElektrik Teknikeri</p>\r\n', 8, ''),
(15, 'Ömer ÖZGEN', 'Kimya Mühendisi', 'omer_ozgen.jpg', '<p><strong>&Ouml;mer &Ouml;ZGEN&nbsp;</strong><br />\r\nKimya M&uuml;hendisi</p>\r\n', 9, ''),
(16, 'M.Mete Yalvaç', 'Makine Mühendisi', 'mmete_yalvac.jpg', '<p><strong>M.Mete Yalva&ccedil;</strong><br />\r\nMakine M&uuml;hendisi</p>\r\n', 10, ''),
(17, 'Ahmet BOZKURT', 'Makine Mühendisi', 'ahmet_bozkurt.jpg', '<p><strong>Ahmet BOZKURT</strong><br />\r\nMakine M&uuml;hendisi</p>\r\n', 11, ''),
(18, 'Erhan ERDEM', 'Jeoloji Yüksek Mühendisi', 'erhan_erdem.jpg', '<p><strong>Erhan ERDEM</strong><br />\r\nJeoloji Y&uuml;ksek M&uuml;hendisi</p>\r\n', 12, ''),
(19, 'Murat DALAY', 'Mimar', 'murat_dalay.jpg', '<p><strong>Murat DALAY</strong><br />\r\nMimar</p>\r\n', 13, ''),
(20, 'Zeynep YAVUZ', 'Sekreter', 'zeynep_yavuz.jpg', '<p><strong>Zeynep YAVUZ</strong><br />\r\nSekreter</p>\r\n', 14, '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmetlerimiz`
--

CREATE TABLE IF NOT EXISTS `hizmetlerimiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(200) NOT NULL,
  `resim` varchar(100) NOT NULL,
  `aciklama` mediumtext NOT NULL,
  `siralama` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Tablo döküm verisi `hizmetlerimiz`
--

INSERT INTO `hizmetlerimiz` (`id`, `baslik`, `resim`, `aciklama`, `siralama`) VALUES
(2, 'Mimari etüt çalışmaları, avan  projelerve uygulama projelerinin  hazırlanması.    ', 'as.jpg', '<p>Mimari et&uuml;t &ccedil;alışmaları, avan &nbsp;projelerve uygulama projelerinin &nbsp;hazırlanması. &nbsp; &nbsp;Mimari et&uuml;t &ccedil;alışmaları, avan &nbsp;projelerve uygulama projelerinin &nbsp;hazırlanması. &nbsp; &nbsp;Mimari et&uuml;t &ccedil;alışmaları, avan &nbsp;projelerve uygulama projelerinin &nbsp;hazırlanması. &nbsp; &nbsp;Mimari et&uuml;t &ccedil;alışmaları, avan &nbsp;projelerve uygulama projelerinin &nbsp;hazırlanması. &nbsp; &nbsp;</p>\r\n', 1),
(4, 'Jeolojik zemin etüt sondaj çalışmalarının yapılması ve jeolojik-jeofizik etüt raporlarının hazırlanması.', '185f7f36.jpg', '<p>Jeolojik zemin et&uuml;t sondaj &ccedil;alışmalarının yapılması ve jeolojik-jeofizik et&uuml;t raporlarının hazırlanması.</p>\r\n', 0),
(5, 'Statik projelerin hazırlanması.', '1988db97.jpg', '<p>&nbsp;Statik projelerin hazırlanması. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n', 2),
(6, ' Dış cephe ve iç mekan projelerinin hazırlanması. 3D Sunumlar', '200561d3.jpg', '<p>&nbsp;Dış cephe ve i&ccedil; mekan projelerinin hazırlanması. 3D Sunumlar</p>\r\n', 3),
(7, ' Elektrik projelerinin hazırlanması.', '21a5a479.jpg', '<p>&nbsp;Elektrik projelerinin hazırlanması. . &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n', 4),
(8, 'Harita tus dosyalarının  hazırlanması.', '22deba48.jpg', '<p>&nbsp;Harita tus dosyalarının &nbsp;hazırlanması.</p>\r\n', 5),
(9, 'Sıhhi Tesisat Projelerinin  Hazırlanması', '23ad6479.jpg', '<p>&nbsp;Sıhhi Tesisat Projelerinin &nbsp;Hazırlanması</p>\r\n', 6),
(10, ' Peyzaj projelerinin hazırlanması.', '24dd266b.jpg', '<p>&nbsp;Peyzaj projelerinin hazırlanması. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n', 7);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kurumsal`
--

CREATE TABLE IF NOT EXISTS `kurumsal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik_tr` varchar(100) COLLATE utf8_bin NOT NULL,
  `baslik_en` varchar(100) COLLATE utf8_bin NOT NULL,
  `url` varchar(100) COLLATE utf8_bin NOT NULL,
  `resim` varchar(100) COLLATE utf8_bin NOT NULL,
  `resim_visible` int(11) NOT NULL,
  `icerik_tr` mediumtext COLLATE utf8_bin NOT NULL,
  `icerik_en` text COLLATE utf8_bin NOT NULL,
  `siralama` int(11) NOT NULL,
  `sol_menu_visible` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

--
-- Tablo döküm verisi `kurumsal`
--

INSERT INTO `kurumsal` (`id`, `baslik_tr`, `baslik_en`, `url`, `resim`, `resim_visible`, `icerik_tr`, `icerik_en`, `siralama`, `sol_menu_visible`) VALUES
(1, 'Hakkımızda', 'About Us', 'hakkimizda', 'hakkimizda.jpg', 1, '<p>Yapıtek proje grubumuz, 1995 yılından beri yaklaşık 20 yılı aşkın s&uuml;redir konusunda uzman deneyimli teknik kadrosu ile &ccedil;eşitli &ouml;l&ccedil;eklerde konut, ofis, karma kullanımlı bina, end&uuml;striyel yapılar ve otel projeleri yapmaktadır.</p>\r\n\r\n<p><strong>Firmamız;</strong></p>\r\n\r\n<p>Mimari tasarım s&uuml;reci ve avan proje aşamasından başlayarak; nitelikli, ilgili y&ouml;netmeliklere uygun, enerji performansına y&ouml;nelik tasarım anlayışını dikkate alan, doğal &ccedil;evre ile uyumlu, doğru tasarım kararları ile yaratıcı &ccedil;&ouml;z&uuml;mler uygulayarak, keyifle yaşanacak mek&acirc;nların uygulama projelerini titiz bir &ccedil;alışma ile hazırlamaktadır.</p>\r\n\r\n<p>Bug&uuml;ne kadar firmamız tarafından &ccedil;ok sayıda b&uuml;y&uuml;k hacimli konut projeleri hazırlanmıştır. Elde etmiş olduğumuz planlama stratejisi, doğru yerleşim kararları ve &ouml;zg&uuml;n tasarımlarımızla hazırlamış olduğumuz projelerin tamamı uygulanmıştır.</p>\r\n\r\n<p>Firmamız m&uuml;şterilerine daha iyi hizmet verebilmek i&ccedil;in sekt&ouml;rdeki gelişmeleri takip ederek kendisini s&uuml;rekli geliştirmektedir.</p>\r\n\r\n<p>T&uuml;m ilişkilerinde karşılıklı g&uuml;veni &ouml;nemseyen firmamız proje y&ouml;netiminde de işlevsel, yapısal ve estetik &ouml;l&ccedil;&uuml;tlere g&ouml;re en uygun tasarımı sunmak i&ccedil;in &ccedil;&ouml;z&uuml;mler &uuml;retmektedir.</p>\r\n\r\n<p>Şirketimiz m&uuml;şteri memnuniyeti ve bug&uuml;ne kadar yapmış olduğu başarılı &ccedil;alışmalarla sekt&ouml;r&uuml;nde &ouml;nemli bir konuma gelmiştir.</p>\r\n', '<p>Yapıtek proje grubumuz, 1995 yılından beri yaklaşık 20 yılı aşkın s&uuml;redir konusunda uzman deneyimli teknik kadrosu ile &ccedil;eşitli &ouml;l&ccedil;eklerde konut, ofis, karma kullanımlı bina, end&uuml;striyel yapılar ve otel projeleri yapmaktadır.</p>\r\n\r\n<p><strong>Firmamız;</strong></p>\r\n\r\n<p>Mimari tasarım s&uuml;reci ve avan proje aşamasından başlayarak; nitelikli, ilgili y&ouml;netmeliklere uygun, enerji performansına y&ouml;nelik tasarım anlayışını dikkate alan, doğal &ccedil;evre ile uyumlu, doğru tasarım kararları ile yaratıcı &ccedil;&ouml;z&uuml;mler uygulayarak, keyifle yaşanacak mek&acirc;nların uygulama projelerini titiz bir &ccedil;alışma ile hazırlamaktadır.</p>\r\n\r\n<p>Bug&uuml;ne kadar firmamız tarafından &ccedil;ok sayıda b&uuml;y&uuml;k hacimli konut projeleri hazırlanmıştır. Elde etmiş olduğumuz planlama stratejisi, doğru yerleşim kararları ve &ouml;zg&uuml;n tasarımlarımızla hazırlamış olduğumuz projelerin tamamı uygulanmıştır.</p>\r\n\r\n<p>Firmamız m&uuml;şterilerine daha iyi hizmet verebilmek i&ccedil;in sekt&ouml;rdeki gelişmeleri takip ederek kendisini s&uuml;rekli geliştirmektedir.</p>\r\n\r\n<p>T&uuml;m ilişkilerinde karşılıklı g&uuml;veni &ouml;nemseyen firmamız proje y&ouml;netiminde de işlevsel, yapısal ve estetik &ouml;l&ccedil;&uuml;tlere g&ouml;re en uygun tasarımı sunmak i&ccedil;in &ccedil;&ouml;z&uuml;mler &uuml;retmektedir.</p>\r\n\r\n<p>Şirketimiz m&uuml;şteri memnuniyeti ve bug&uuml;ne kadar yapmış olduğu başarılı &ccedil;alışmalarla sekt&ouml;r&uuml;nde &ouml;nemli bir konuma gelmiştir.</p>\r\n', 0, 1),
(2, 'Vizyon & Misyon', 'Our Vision & Our Mission', 'vizyon___misyon', 'vizyon_misyon.png', 1, '<p><strong>Vizyonumuz</strong><br />\r\nTeknolojiyi en iyi şekilde kullanarak, hizmet kalitesini, donanımını s&uuml;rekli yenilemek, sistemli, yenilik&ccedil;i, girişimci ve g&uuml;venilir &uuml;nvana sahip bir &quot;d&uuml;nya şirketi&quot;olmaktır.</p>\r\n\r\n<p>&nbsp;&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Misyonumuz</strong><br />\r\nM&uuml;şterisine, &ccedil;alışanına ve yasalara saygılı; g&uuml;venilir, yenilik&ccedil;i , atılımcı y&ouml;netim ve hizmet anlayışıyla s&uuml;rekli gelişmeyi sağlamaktır.</p>\r\n', '<p><strong>Vizyonumuz</strong><br />\r\nTeknolojiyi en iyi şekilde kullanarak, hizmet kalitesini, donanımını s&uuml;rekli yenilemek, sistemli, yenilik&ccedil;i, girişimci ve g&uuml;venilir &uuml;nvana sahip bir &quot;d&uuml;nya şirketi&quot;olmaktır.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Misyonumuz</strong><br />\r\nM&uuml;şterisine, &ccedil;alışanına ve yasalara saygılı; g&uuml;venilir, yenilik&ccedil;i , atılımcı y&ouml;netim ve hizmet anlayışıyla s&uuml;rekli gelişmeyi sağlamaktır.</p>\r\n', 1, 1),
(3, 'Çevre Politikamız', 'Our Environmental Policy', 'cevre_politikamiz', 'cevre_politikamiz.png', 1, '<p>&bull; &Ccedil;evre kanunu, enerji verimliliği kanunu ve ilgili y&ouml;netmeliklere harfiyen uymak ve geliştirici &ouml;nerileri yetkililere sunmaktır.</p>\r\n\r\n<p>&bull; Proje tasarımında &ccedil;evresel kriterleri dikkate alan; g&ouml;r&uuml;nt&uuml;, g&uuml;r&uuml;lt&uuml; kirliliği yaratmayan, evsel atık sorunlarını minimuma indirecek en ileri sistemleri araştırmak ve kullanmaktır.</p>\r\n\r\n<p>&bull; Yenilenebilir enerji sistemlerinin uygulanmasını dikkate alarak daha az enerji ve su kullanma y&ouml;ntemlerini proje tasarımında tercih edip uygulamak ve başkalarına da &ouml;zendirmektir.</p>\r\n', '<p>&bull; &Ccedil;evre kanunu, enerji verimliliği kanunu ve ilgili y&ouml;netmeliklere harfiyen uymak ve geliştirici &ouml;nerileri yetkililere sunmaktır.</p>\r\n\r\n<p>&bull; Proje tasarımında &ccedil;evresel kriterleri dikkate alan; g&ouml;r&uuml;nt&uuml;, g&uuml;r&uuml;lt&uuml; kirliliği yaratmayan, evsel atık sorunlarını minimuma indirecek en ileri sistemleri araştırmak ve kullanmaktır.</p>\r\n\r\n<p>&bull; Yenilenebilir enerji sistemlerinin uygulanmasını dikkate alarak daha az enerji ve su kullanma y&ouml;ntemlerini proje tasarımında tercih edip uygulamak ve başkalarına da &ouml;zendirmektir.</p>\r\n', 2, 1),
(4, 'Kalite Politikamız', 'Our quality policy', 'kalite_politikamiz', 'kalite_politikamiz.jpg', 1, '<p>&bull; &Ccedil;evre kanunu, enerji verimliliği kanunu ve ilgili y&ouml;netmeliklere harfiyen uymak ve geliştirici &ouml;nerileri yetkililere sunmaktır.</p>\r\n\r\n<p>&bull; Proje tasarımında &ccedil;evresel kriterleri dikkate alan; g&ouml;r&uuml;nt&uuml;, g&uuml;r&uuml;lt&uuml; kirliliği yaratmayan, evsel atık sorunlarını minimuma indirecek en ileri sistemleri araştırmak ve kullanmaktır.</p>\r\n\r\n<p>&bull; Yenilenebilir enerji sistemlerinin uygulanmasını dikkate alarak daha az enerji ve su kullanma y&ouml;ntemlerini proje tasarımında tercih edip uygulamak ve başkalarına da &ouml;zendirmektir.</p>\r\n', '<p>&bull; &Ccedil;evre kanunu, enerji verimliliği kanunu ve ilgili y&ouml;netmeliklere harfiyen uymak ve geliştirici &ouml;nerileri yetkililere sunmaktır.</p>\r\n\r\n<p>&bull; Proje tasarımında &ccedil;evresel kriterleri dikkate alan; g&ouml;r&uuml;nt&uuml;, g&uuml;r&uuml;lt&uuml; kirliliği yaratmayan, evsel atık sorunlarını minimuma indirecek en ileri sistemleri araştırmak ve kullanmaktır.</p>\r\n\r\n<p>&bull; Yenilenebilir enerji sistemlerinin uygulanmasını dikkate alarak daha az enerji ve su kullanma y&ouml;ntemlerini proje tasarımında tercih edip uygulamak ve başkalarına da &ouml;zendirmektir.</p>\r\n', 3, 1),
(5, 'İnsan Kaynakları', 'Human resources', 'insan_kaynaklari', 'insan_kaynaklari.jpg', 1, '<p>İnsan Kaynakları b&ouml;l&uuml;m&uuml;m&uuml;zle iletişime ge&ccedil;ip bizimle &ccedil;alışmak i&ccedil;in l&uuml;ften aşağıdaki aranan nitelikleri okuyup, bize detaylı cv&#39; nizi mail atınız.</p>\r\n\r\n<p>Firmamız b&uuml;nyesinde projelerde g&ouml;revlendirilmek &uuml;zere;</p>\r\n\r\n<p>İlgili b&ouml;l&uuml;mlerin 4 yıllık b&ouml;l&uuml;mlerinden mezun veya iyi derecede &ccedil;izim yapabilme kabiliyetine sahip olmak,</p>\r\n\r\n<p>Askerlikle ilgili bir ilişiği bulunmamak,</p>\r\n', '<p>İnsan Kaynakları b&ouml;l&uuml;m&uuml;m&uuml;zle iletişime ge&ccedil;ip bizimle &ccedil;alışmak i&ccedil;in l&uuml;ften aşağıdaki aranan nitelikleri okuyup, bize detaylı cv&#39; nizi mail atınız.</p>\r\n\r\n<p>Firmamız b&uuml;nyesinde projelerde g&ouml;revlendirilmek &uuml;zere;</p>\r\n\r\n<p>İlgili b&ouml;l&uuml;mlerin 4 yıllık b&ouml;l&uuml;mlerinden mezun veya iyi derecede &ccedil;izim yapabilme kabiliyetine sahip olmak,</p>\r\n\r\n<p>Askerlikle ilgili bir ilişiği bulunmamak,</p>\r\n', 4, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesaj`
--

CREATE TABLE IF NOT EXISTS `mesaj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isim` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mesaj` text NOT NULL,
  `tarih` varchar(100) NOT NULL,
  `okundu` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `mesaj`
--

INSERT INTO `mesaj` (`id`, `isim`, `email`, `mesaj`, `tarih`, `okundu`) VALUES
(1, 'anil', 'anil@anil.com', 'tarih tarih tarih tarih ', '2015-09-05', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `projeler`
--

CREATE TABLE IF NOT EXISTS `projeler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proje_adi` varchar(100) COLLATE utf8_bin NOT NULL,
  `proje_url` varchar(100) COLLATE utf8_bin NOT NULL,
  `proje_ozellikleri` mediumtext COLLATE utf8_bin NOT NULL,
  `siralama` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

--
-- Tablo döküm verisi `projeler`
--

INSERT INTO `projeler` (`id`, `proje_adi`, `proje_url`, `proje_ozellikleri`, `siralama`) VALUES
(1, 'Dalgıç Plaza', 'dalgic_plaza', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 0),
(2, 'Marveleus ', 'marveleus', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 1),
(3, 'Nidus Konutları', 'nidus_konutlari', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 2),
(4, 'Sancar Plaza', 'sancar_plaza', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 3),
(5, 'Akış Plaza', 'akis_plaza', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 4),
(6, 'Aros Plaza', 'aros_plaza', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 5),
(7, 'Majestik Plaza', 'majestik_plaza', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 6),
(8, 'Everekli İnşaat', 'everekli_insaat', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 7),
(9, 'İstinye Park', 'istinye_park', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 8),
(10, 'Kuzey İnşaat', 'kuzey_insaat', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 9),
(11, 'Gündoğar İnşaat', 'gundogar_insaat', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 10),
(12, 'Modalife', 'modalife', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 11),
(13, 'Mezitli 360', 'mezitli_360', '<p>Lorem ipsum dolor slo onsec nelioro tueraliquet Morbi nec In Curabitur lreaoreet nisl lorem in design Morbi nec In</p>\r\n', 12);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `projeler_resim`
--

CREATE TABLE IF NOT EXISTS `projeler_resim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proje_id` int(11) NOT NULL,
  `url` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=32 ;

--
-- Tablo döküm verisi `projeler_resim`
--

INSERT INTO `projeler_resim` (`id`, `proje_id`, `url`) VALUES
(3, 2, 'marveleus1.jpg'),
(9, 1, 'dalgic_plaza1_1.jpg'),
(10, 1, 'dalgic_plaza2.jpg'),
(11, 2, 'marveleus2.jpg'),
(12, 2, 'marveleus3.jpg'),
(13, 2, 'marveleus4.jpg'),
(14, 1, 'dalgic3.jpg'),
(15, 1, 'dalgic4.jpg'),
(16, 1, 'dalgic5.jpg'),
(17, 3, 'nidus1.jpg'),
(18, 3, 'nidus2.jpg'),
(19, 3, 'nidus3.jpg'),
(20, 4, 'sancar2.jpg'),
(21, 4, 'sancar3.jpg'),
(22, 4, 'sancar4.jpg'),
(23, 5, '1.jpg'),
(24, 6, '1_1.jpg'),
(25, 7, '2_1.jpg'),
(26, 8, '1_2.jpg'),
(27, 9, '1_3.jpg'),
(28, 10, '1_4.jpg'),
(29, 11, 'magestikA900px.jpg'),
(30, 12, '1_5.jpg'),
(31, 13, '1_6.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
